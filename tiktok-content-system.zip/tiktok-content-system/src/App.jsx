import { useState, useRef } from "react";

// ── API headers — works both on Claude.ai Artifacts (no key) and local dev (.env) ──
function getHeaders() {
  const headers = { "Content-Type": "application/json" };
  const key = typeof import.meta !== "undefined" && import.meta.env?.VITE_ANTHROPIC_API_KEY;
  if (key) {
    headers["x-api-key"] = key;
    headers["anthropic-version"] = "2023-06-01";
    headers["anthropic-dangerous-direct-browser-access"] = "true";
  }
  return headers;
}

// ───────── Static Data ─────────
const HOOKS = [
  { id:"H1", type:"ปัญหา-สะกิดใจ", label:"Pain Hook", color:"#FF3B5C", icon:"😱",
    formula:"[ปัญหาที่คนกลัว] + [ตัวเลขที่น่าตกใจ] + [คำถามกระตุก]", stopTrigger:"ความกลัวพลาด / FOMO",
    examples:["ทำไมครีมแพง ๆ ทาแล้วหน้ายังไม่ขาว? เพราะ 90% คนทำผิดแบบนี้...","อายุ 25 หน้าแก่กว่าเพื่อน เพราะขั้นตอนนี้ที่พลาดทุกวัน","ซื้อครีมมา 3 กระปุกแต่หน้าไม่เปลี่ยน? ดูนี่ก่อน"] },
  { id:"H2", type:"ผลลัพธ์-ล่อใจ", label:"Result Hook", color:"#FF6B35", icon:"✨",
    formula:"[ผลลัพธ์ที่อยากได้] + [เวลาที่สั้นที่สุด] + [หลักฐาน/ตัวเลข]", stopTrigger:"ความหวัง / Desire",
    examples:["หน้าขาวกระจ่างใน 7 วัน แค่เปลี่ยนวิธีนี้อย่างเดียว","ทาแค่ 2 สเต็ป รูขุมขนหายใน 14 วัน ของจริงไม่ตัดต่อ","ก่อน-หลัง 30 วัน ไม่ต้องรีทัช ไม่ต้องกรอง"] },
  { id:"H3", type:"ลับ-เปิดเผย", label:"Secret Hook", color:"#7B2FBE", icon:"🤫",
    formula:"[ความลับ/สิ่งที่คนไม่รู้] + [กลุ่มที่รู้แล้ว] + [คำสัญญาว่าจะบอก]", stopTrigger:"ความอยากรู้ / Curiosity",
    examples:["สูตรที่พนักงานสปาใช้เองแต่ไม่บอกลูกค้า มาแชร์ให้เลย","ทำไมสาวเกาหลีหน้าเงาตลอด 24 ชม.? ความลับอยู่ที่สเต็ปที่ 3","บิวตี้บล็อกเกอร์ไม่บอก แต่วันนี้จะบอกเอง"] },
];

const CONTENT_TYPES = [
  { id:"CT1", name:"GRWM (Get Ready With Me)", icon:"💄", color:"#FF3B5C", narrative:"เล่าเรื่องผ่านชีวิตจริง",
    structure:[{step:1,label:"HOOK 3 วิ",desc:"เปิดด้วยใบหน้าก่อนแต่งหรือปัญหาที่เห็นชัด"},{step:2,label:"Context",desc:"บอกว่าวันนี้ไปไหน ทำไมถึงต้องแต่งแบบนี้"},{step:3,label:"Product Insert",desc:"หยิบสินค้าขึ้นมา + บอกว่าแก้ปัญหาอะไร"},{step:4,label:"Demo",desc:"แสดงวิธีใช้ + Texture + ผลลัพธ์ทันที"},{step:5,label:"Social Proof",desc:"บอก Rating / ยอดขาย / รีวิวจริง"},{step:6,label:"CTA",desc:"ปิดด้วยราคา + ลิงก์ + Urgency"}],
    productInsertScript:"พอดีวันนี้ใช้ [ชื่อสินค้า] ตัวนี้ ที่ใช้มา [X] เดือนแล้ว มันช่วยเรื่อง [ปัญหา] ได้จริง ๆ ราคาแค่ [ราคา]" },
  { id:"CT2", name:"Before & After", icon:"🔄", color:"#FF6B35", narrative:"เล่าเรื่องผ่านการเปลี่ยนแปลง",
    structure:[{step:1,label:"HOOK 3 วิ",desc:"ภาพ Before ชัด ๆ พร้อมข้อความปัญหา"},{step:2,label:"Pain Point",desc:"เล่าความทุกข์ก่อนใช้สินค้า 10-15 วิ"},{step:3,label:"Discovery",desc:"เจอสินค้านี้ได้ยังไง? มีเรื่องน่าสนใจ"},{step:4,label:"Journey",desc:"ใช้ยังไง ใช้นานแค่ไหน Timeline ชัดเจน"},{step:5,label:"After Reveal",desc:"ภาพ After + ตัวเลขที่วัดได้"},{step:6,label:"CTA",desc:"ปิดแบบ Exclusive + กดลิงก์"}],
    productInsertScript:"ตอนแรกก็ไม่เชื่อหรอก แต่หลังใช้ [สินค้า] ครบ [X] วัน [ผลลัพธ์] จริง ๆ ไม่ได้ตัดต่อ" },
  { id:"CT3", name:"Tutorial / How-to", icon:"📋", color:"#0A84FF", narrative:"เล่าเรื่องผ่านความรู้",
    structure:[{step:1,label:"HOOK 3 วิ",desc:"บอก Output ที่จะได้ก่อนเลย"},{step:2,label:"Why",desc:"ทำไมวิธีนี้ถึงได้ผล (Credibility)"},{step:3,label:"Step 1-3",desc:"สอนทีละขั้น แทรกสินค้าในขั้นที่สำคัญที่สุด"},{step:4,label:"Mistake",desc:"บอก 1 ข้อผิดพลาดที่คนมักทำ"},{step:5,label:"Result",desc:"แสดงผลลัพธ์สุดท้าย"},{step:6,label:"CTA",desc:"ปิดด้วย Save วิดีโอนี้ + ลิงก์ซื้อ"}],
    productInsertScript:"ขั้นตอนที่สำคัญที่สุดคือตรงนี้ ต้องใช้ [สินค้า] เพราะ [reason based on ingredient/benefit]" },
  { id:"CT4", name:"Review / Unboxing", icon:"📦", color:"#30D158", narrative:"เล่าเรื่องผ่านความจริงใจ",
    structure:[{step:1,label:"HOOK 3 วิ",desc:"เปิดกล่อง + บอก Price Point ที่ทำให้ตกใจ"},{step:2,label:"First Impression",desc:"ความรู้สึกแรก Packaging + Texture"},{step:3,label:"Key Ingredients",desc:"Highlight 2-3 ส่วนผสมที่ขายได้"},{step:4,label:"Application",desc:"ทาสด ให้เห็น Real-time Reaction"},{step:5,label:"Verdict",desc:"คะแนน + เปรียบเทียบกับคู่แข่ง"},{step:6,label:"CTA",desc:"ปิดด้วยโปรโมชั่น + Flash Sale Warning"}],
    productInsertScript:"ราคา [ราคา] แต่ได้ของที่ระดับ [คู่แข่งแพงกว่า X เท่า] เลยซื้อซ้ำมาแล้ว [X] รอบ" },
];

const CTA_BANK = [
  { type:"Urgency", label:"⏰ Flash Sale", text:"ราคานี้แค่วันนี้วันเดียว พรุ่งนี้ราคาปกติเลย กดตะกร้าไว้ก่อนเลยนะ", trigger:"FOMO" },
  { type:"Social Proof", label:"👥 Social Proof", text:"คนซื้อไปแล้ว [X] ออเดอร์วันนี้ ใครยังไม่ได้กดรีบเลยนะ", trigger:"Herd Behavior" },
  { type:"Anchor Price", label:"💰 Price Anchor", text:"ปกติราคา [ราคาเต็ม] แต่วันนี้เหลือ [ราคาลด] เซฟไป [จำนวนเงิน] เลยนะ", trigger:"Perceived Value" },
  { type:"Bundle", label:"🎁 Bundle Bait", text:"ซื้อ [X] ชิ้น ได้ฟรีอีก [Y] ชิ้น ส่งฟรีด้วย กดที่ลิงก์ใน Bio เลย", trigger:"Value Maximizer" },
  { type:"Scarcity", label:"📦 Stock Scarcity", text:"เหลืออยู่แค่ [จำนวน] ชิ้น รอบที่แล้วหมดใน 2 ชม. กดเก็บไว้ก่อนเลย", trigger:"Loss Aversion" },
  { type:"Repurchase", label:"🔄 Repurchase Seed", text:"อันนี้ใช้หมดขวดที่ [X] แล้ว สั่งอีกรอบมาสต็อคไว้เลย ไม่อยากขาด", trigger:"Habit Loop" },
  { type:"Gift", label:"🎀 Gift Framing", text:"ซื้อให้ตัวเองก็ดี ซื้อให้แฟนก็ดี แพ็คเกจสวยมากนะ", trigger:"Gift Justification" },
];

const HASHTAG_SETS = {
  กลุ่มสินค้า: ["#TikTokShopไทย","#สินค้าดี","#ของดีบอกต่อ","#ช้อปปิ้งออนไลน์"],
  ความงาม: ["#สกินแคร์","#ครีมทาหน้า","#หน้าขาว","#รูขุมขน","#เมคอัพ"],
  พฤติกรรม: ["#GRWM","#BeforeAfter","#สกินแคร์รูทีน","#ทิปส์ความงาม"],
  ไวรัล: ["#fyp","#fypシ","#viral","#ทิกตอก"],
  ซื้อ: ["#ซื้อเลย","#ลิงก์ใน Bio","#โปรวันนี้","#ราคาพิเศษ"],
};

const REPURCHASE_TACTICS = [
  { tactic:"Bundle Mention", script:"ครั้งหน้าจะลองซื้อคู่กับ [สินค้า B] ใครเคยลองแล้วเป็นยังไงบ้าง?" },
  { tactic:"Stock Up Signal", script:"ซื้อสต็อคไว้ 2 ชิ้นเลย กลัวของหมด รอบที่แล้วรอรีสต็อกนาน" },
  { tactic:"Routine Lock-in", script:"ตอนนี้นี่คือของที่ขาดไม่ได้ในรูทีนเช้าเลย ใช้มาทุกวันไม่เคยข้ามเลย" },
  { tactic:"Community Challenge", script:"ลอง [สินค้า] ติดต่อกัน 30 วัน แล้วมา Update ผล มา Challenge ด้วยกัน" },
  { tactic:"Subscribe Nudge", script:"กด Subscribe ใน Shop เลย จะได้รู้ก่อนเวลามีโปร เดือนที่แล้วโปรหมดใน 1 วัน" },
];

// ── helpers ──
function toBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result.split(",")[1]);
    r.onerror = () => rej(new Error("อ่านไฟล์ไม่ได้"));
    r.readAsDataURL(file);
  });
}

function resizeImage(file, maxPx = 900) {
  return new Promise((res) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, maxPx / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      canvas.toBlob(blob => res(blob), "image/jpeg", 0.85);
    };
    img.src = url;
  });
}

function extractTikTokInfo(url) {
  // Extract product ID and shop info from TikTok Shop URL patterns
  const patterns = [
    /tiktok\.com\/@([^/]+)\/product\/(\d+)/,
    /tiktok\.com\/t\/([A-Za-z0-9]+)/,
    /vm\.tiktok\.com\/([A-Za-z0-9]+)/,
    /item_id=(\d+)/,
    /product\/(\d+)/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return { raw: url, extracted: m[0], id: m[m.length - 1] };
  }
  return { raw: url, extracted: url, id: null };
}


// ── Video frame sampler ──
// Extracts N evenly-spaced frames from a video file as base64 JPEGs
function sampleVideoFrames(file, numFrames = 6) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.muted = true;
    video.preload = "metadata";
    video.src = url;
    const frames = [];
    let captured = 0;

    video.onloadedmetadata = () => {
      const duration = video.duration;
      const canvas = document.createElement("canvas");
      canvas.width = 360;
      canvas.height = 640;
      const ctx = canvas.getContext("2d");

      const captureAt = (time) => new Promise((res) => {
        video.currentTime = time;
        video.onseeked = () => {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          canvas.toBlob(blob => {
            const reader = new FileReader();
            reader.onload = () => res(reader.result.split(",")[1]);
            reader.readAsDataURL(blob);
          }, "image/jpeg", 0.75);
        };
      });

      const times = Array.from({ length: numFrames }, (_, i) =>
        Math.min((duration / (numFrames + 1)) * (i + 1), duration - 0.1)
      );

      (async () => {
        for (const t of times) {
          try { frames.push(await captureAt(t)); } catch(e) {}
        }
        URL.revokeObjectURL(url);
        resolve(frames);
      })();
    };
    video.onerror = () => { URL.revokeObjectURL(url); resolve([]); };
  });
}

// ── Analyze a single clip with its frames ──
async function analyzeClipWithAI(clipName, clipUrl, frames, productContext) {
  const frameImages = frames.slice(0, 4).map(b64 => ({
    type: "image",
    source: { type: "base64", media_type: "image/jpeg", data: b64 }
  }));

  const prompt = `คุณคือผู้เชี่ยวชาญวิเคราะห์คลิป TikTok Shop เพื่อเพิ่ม GMV สูงสุด

ข้อมูลสินค้า: ${productContext}
ลิงก์คลิป: ${clipUrl || "ไม่ระบุ"}
ชื่อไฟล์: ${clipName}

ภาพที่แนบคือ frame ที่ sample มาจากวิดีโอ ${frames.length} frame (เรียงตามเวลา)

วิเคราะห์โครงสร้างคลิปจาก frame เหล่านี้ แล้วตอบ JSON เท่านั้น:
{
  "clipTitle": "ชื่อ/ธีมคลิปที่คาดว่าใช้",
  "contentType": "GRWM | Before&After | Tutorial | Review | Unboxing | Challenge | Other",
  "duration": "สั้น(<30s) | กลาง(30-60s) | ยาว(>60s)",
  "hookAnalysis": {
    "hookType": "Pain | Result | Secret | Curiosity | Shock | Story",
    "hookScript": "สคริปต์ hook ที่คาดว่าใช้ใน 3 วิแรก (จาก frame แรก)",
    "hookStrength": "Strong | Medium | Weak",
    "hookReason": "ทำไม hook นี้ถึงได้ผล/ไม่ได้ผล"
  },
  "scriptStructure": [
    {"second": "0-3", "element": "Hook", "description": "สิ่งที่เห็นใน frame แรก", "gmvImpact": "High|Med|Low"},
    {"second": "3-10", "element": "Problem/Context", "description": "การเล่าปัญหา", "gmvImpact": "High|Med|Low"},
    {"second": "10-25", "element": "Product Demo", "description": "วิธีแสดงสินค้า", "gmvImpact": "High|Med|Low"},
    {"second": "25-40", "element": "Result/Proof", "description": "การแสดงผลลัพธ์", "gmvImpact": "High|Med|Low"},
    {"second": "40+", "element": "CTA", "description": "การปิดการขาย", "gmvImpact": "High|Med|Low"}
  ],
  "ctaAnalysis": {
    "ctaType": "Flash Sale | Scarcity | Social Proof | Bundle | Gift | Soft CTA",
    "ctaScript": "สคริปต์ CTA ที่คาดว่าใช้ (จาก frame สุดท้าย)",
    "ctaStrength": "Strong | Medium | Weak",
    "ctaPlacement": "ดีมาก | ควรเร็วกว่านี้ | ควรช้ากว่านี้"
  },
  "visualElements": {
    "hasTextOverlay": true,
    "hasProductCloseup": true,
    "hasBeforeAfter": false,
    "hasFaceReaction": true,
    "productVisibility": "High | Medium | Low"
  },
  "hashtags": "#แท็กที่เหมาะสมที่สุด 10-12 แท็ก",
  "gmvScore": 78,
  "gmvBreakdown": {
    "hookScore": 80,
    "demoScore": 75,
    "ctaScore": 70,
    "trustScore": 85
  },
  "strengths": ["จุดแข็ง 1", "จุดแข็ง 2"],
  "weaknesses": ["จุดอ่อน 1", "จุดอ่อน 2"],
  "improvements": ["การปรับปรุงที่จะเพิ่ม GMV มากที่สุด 1", "การปรับปรุง 2", "การปรับปรุง 3"]
}`;

  const msgContent = [...frameImages, { type: "text", text: prompt }];

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: "คุณคือผู้เชี่ยวชาญ TikTok Shop GMV Optimizer ตอบ JSON เท่านั้น ห้ามมีข้อความอื่น",
      messages: [{ role: "user", content: msgContent }]
    })
  });
  const data = await resp.json();
  const raw = data.content?.map(i => i.text || "").join("") || "";
  const clean = raw.replace(/```json|```/g, "").trim();
  return JSON.parse(clean);
}

// ── Synthesize insights from all clips ──
async function synthesizeClipInsights(clipResults, productContext) {
  const summary = clipResults.map((r, i) =>
    `คลิป ${i+1} (${r.clipName}): GMV=${r.analysis?.gmvScore} hookType=${r.analysis?.hookAnalysis?.hookType} ctaType=${r.analysis?.ctaAnalysis?.ctaType} contentType=${r.analysis?.contentType} จุดแข็ง=${(r.analysis?.strengths||[]).join(",")} จุดอ่อน=${(r.analysis?.weaknesses||[]).join(",")}`
  ).join("\n");

  const prompt = `วิเคราะห์คลิปทั้งหมด ${clipResults.length} คลิปของสินค้า: ${productContext}

ข้อมูลแต่ละคลิป:
${summary}

สรุปภาพรวมและ Best Practice ตอบ JSON เท่านั้น:
{
  "overallGMVScore": 75,
  "bestClip": "คลิปที่ ${clipResults.length > 0 ? 1 : 1} - เหตุผล",
  "dominantHook": "Hook ที่ใช้บ่อยและได้ผลที่สุด",
  "dominantCTA": "CTA ที่ใช้บ่อยและได้ผลที่สุด",
  "winningFormula": "สูตรคลิปที่ชนะที่สุดจากข้อมูลทั้งหมด",
  "bestScriptTemplate": {
    "hook": "Hook script ที่ดีที่สุดสำหรับสินค้านี้ (สังเคราะห์จากทุกคลิป)",
    "demo": "วิธี demo สินค้าที่ดีที่สุด",
    "proof": "วิธีแสดง social proof ที่ดีที่สุด",
    "cta": "CTA ที่ดีที่สุดสำหรับสินค้านี้"
  },
  "gmvMaxStructure": [
    {"second": "0-3s", "action": "สิ่งที่ต้องทำ", "example": "ตัวอย่างจริง", "why": "เหตุผล"},
    {"second": "3-8s", "action": "สิ่งที่ต้องทำ", "example": "ตัวอย่างจริง", "why": "เหตุผล"},
    {"second": "8-20s", "action": "สิ่งที่ต้องทำ", "example": "ตัวอย่างจริง", "why": "เหตุผล"},
    {"second": "20-35s", "action": "สิ่งที่ต้องทำ", "example": "ตัวอย่างจริง", "why": "เหตุผล"},
    {"second": "35-45s", "action": "สิ่งที่ต้องทำ", "example": "ตัวอย่างจริง", "why": "เหตุผล"},
    {"second": "45s+", "action": "CTA ปิดการขาย", "example": "ตัวอย่างจริง", "why": "เหตุผล"}
  ],
  "topHashtags": "#แท็ก1 #แท็ก2 ... (15 แท็กที่ดีที่สุดสำหรับสินค้านี้รวมจากทุกคลิป)",
  "avoidList": ["สิ่งที่ทุกคลิปทำแล้วไม่ดี 1", "สิ่งที่ควรหลีกเลี่ยง 2"],
  "nextStepRecommendation": "คำแนะนำสำคัญที่สุดสำหรับคลิปถัดไปเพื่อเพิ่ม GMV สูงสุด"
}`;

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: "คุณคือผู้เชี่ยวชาญ TikTok GMV Strategy ตอบ JSON เท่านั้น",
      messages: [{ role: "user", content: prompt }]
    })
  });
  const data = await resp.json();
  const raw = data.content?.map(i => i.text || "").join("") || "";
  const clean = raw.replace(/```json|```/g, "").trim();
  return JSON.parse(clean);
}


// ── Step indicator ──
function StepBadge({ num, label, active, done }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:"8px", flex:1 }}>
      <div style={{
        width:"26px", height:"26px", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center",
        fontSize:"12px", fontWeight:"700", flexShrink:0,
        background: done ? "#30D158" : active ? "linear-gradient(135deg,#FF3B5C,#7B2FBE)" : "rgba(255,255,255,0.1)",
        color: "#fff",
      }}>{done ? "✓" : num}</div>
      <span style={{ fontSize:"12px", color: active ? "#F0F0F0" : done ? "#30D158" : "rgba(255,255,255,0.35)", fontWeight: active ? "700" : "400" }}>{label}</span>
    </div>
  );
}

// ───────── Product Tab ─────────
function ProductTab() {
  const [products, setProducts] = useState([]);
  const [view, setView] = useState("list");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [aiResult, setAiResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState("");
  const [copiedId, setCopiedId] = useState(null);

  // add-form state
  const [tiktokUrl, setTiktokUrl] = useState("");
  const [imgFile, setImgFile] = useState(null);
  const [imgPreview, setImgPreview] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzed, setAnalyzed] = useState(null);
  const fileRef = useRef();

  const copyText = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const isValidTikTokUrl = (url) =>
    /tiktok\.com|vm\.tiktok|vt\.tiktok/.test(url);

  const canAnalyze = tiktokUrl.trim() && imgFile && isValidTikTokUrl(tiktokUrl);

  // ── Analyze: URL + Image → AI ──
  const handleAnalyze = async () => {
    if (!canAnalyze) return;
    setAnalyzed(null);
    setAnalyzing(true);
    try {
      const resized = await resizeImage(imgFile);
      const b64 = await toBase64(resized);
      const urlInfo = extractTikTokInfo(tiktokUrl);

      const userPrompt = `คุณได้รับข้อมูล 2 อย่างพร้อมกัน:
1. ลิงก์สินค้า TikTok Shop: ${urlInfo.raw}${urlInfo.id ? ` (Product ID: ${urlInfo.id})` : ""}
2. Screenshot หรือรูปสินค้าจาก TikTok Shop (ดูในภาพที่แนบมา)

วิเคราะห์ข้อมูลจากทั้งลิงก์และรูปภาพ แล้วตอบเป็น JSON เท่านั้น ห้ามมีข้อความอื่น:
{
  "productName": "ชื่อสินค้าจากรูปหรือลิงก์",
  "brand": "ชื่อแบรนด์",
  "shopName": "ชื่อร้านถ้าเห็นในรูป",
  "category": "skincare | makeup | haircare | bodycare | supplement | perfume | food | fashion | other",
  "priceRangeTHB": "ราคาที่เห็นในรูป หรือช่วงราคาโดยประมาณ เช่น 199 หรือ 150-250",
  "originalPrice": "ราคาก่อนลดถ้าเห็น",
  "discountPct": "เปอร์เซ็นต์ส่วนลดถ้าเห็น เช่น 30",
  "rating": "คะแนนรีวิวถ้าเห็น เช่น 4.8",
  "soldCount": "ยอดขายถ้าเห็น เช่น 1.2k",
  "keyIngredients": ["ส่วนผสมที่มองเห็น"],
  "keyBenefits": ["สรรพคุณหลัก 3 ข้อที่เหมาะกับสินค้านี้"],
  "contentAngle": "มุมคอนเทนต์ที่เหมาะที่สุด",
  "complianceFlags": ["ข้อระวัง TikTok Policy ที่เกี่ยวข้อง"]
}`;

      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: "คุณคือผู้เชี่ยวชาญสินค้า TikTok Shop ไทย วิเคราะห์จากลิงก์และรูปภาพ ตอบ JSON เท่านั้น",
          messages: [{
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: "image/jpeg", data: b64 } },
              { type: "text", text: userPrompt }
            ]
          }]
        })
      });
      const data = await resp.json();
      const raw = data.content?.map(i => i.text || "").join("") || "";
      const clean = raw.replace(/```json|```/g, "").trim();
      setAnalyzed(JSON.parse(clean));
    } catch (err) {
      setAnalyzed({ error: "วิเคราะห์ไม่ได้ กรุณาลองใหม่" });
    }
    setAnalyzing(false);
  };

  const handleImagePick = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImgFile(file);
    setImgPreview(URL.createObjectURL(file));
    setAnalyzed(null);
  };

  const saveProduct = () => {
    if (!analyzed || analyzed.error) return;
    setProducts(prev => [{
      id: Date.now(),
      imgPreview,
      imgFile,
      tiktokUrl,
      ...analyzed,
    }, ...prev]);
    setTiktokUrl(""); setImgFile(null); setImgPreview(null); setAnalyzed(null);
    setView("list");
  };

  // ── generate full content ──
  const generateContent = async (product) => {
    setSelectedProduct(product);
    setAiResult(null);
    setLoading(true);
    setView("result");

    try {
      let imageContent = null;
      if (product.imgFile) {
        setLoadingStep("📸 โหลดรูปสินค้า...");
        const resized = await resizeImage(product.imgFile);
        const b64 = await toBase64(resized);
        imageContent = { type: "image", source: { type: "base64", media_type: "image/jpeg", data: b64 } };
      }
      setLoadingStep("🤖 AI กำลัง Gen คอนเทนต์...");

      const systemPrompt = `คุณคือผู้เชี่ยวชาญคอนเทนต์ TikTok Shop ไทย ที่รู้กฎ TikTok Community Guidelines และ TikTok Shop Seller Policy อย่างลึกซึ้ง
กฎบังคับ:
- ห้ามอ้างว่าสินค้า "รักษาโรค" หรือมีผลทางการแพทย์
- ห้ามใช้ "รักษา / หาย / รับประกัน 100%" สำหรับผลทางสุขภาพ
- ห้ามเปรียบเทียบแบรนด์คู่แข่งโดยชื่อ
- ห้ามตัวเลขเกินจริง เช่น "ขาวขึ้น 500%"
- ห้ามอ้าง testimonial ที่ไม่มีหลักฐาน
- สคริปต์ต้องฟังดูเป็น personal experience จริง
- ตอบ JSON เท่านั้น`;

      const urlInfo = extractTikTokInfo(product.tiktokUrl || "");
      const userPrompt = `ข้อมูลสินค้า:
ชื่อ: ${product.productName}  |  แบรนด์: ${product.brand || "-"}  |  ร้าน: ${product.shopName || "-"}
ราคา: ฿${product.priceRangeTHB}${product.originalPrice ? ` (ปกติ ฿${product.originalPrice})` : ""}${product.discountPct ? ` ลด ${product.discountPct}%` : ""}
Rating: ${product.rating || "-"}  |  ยอดขาย: ${product.soldCount || "-"}
หมวดหมู่: ${product.category}  |  ส่วนผสม: ${(product.keyIngredients || []).join(", ")}
สรรพคุณ: ${(product.keyBenefits || []).join(", ")}
มุมคอนเทนต์: ${product.contentAngle || "ทั่วไป"}
TikTok URL: ${urlInfo.raw || "-"}

สร้างคอนเทนต์ครบชุด ตอบ JSON:
{
  "complianceStatus": "PASS หรือ WARN",
  "complianceNote": "สถานะและข้อแนะนำ",
  "productSummary": "สรุปจุดขาย 1-2 ประโยค",
  "keySellingPoints": ["จุดขาย 1","จุดขาย 2","จุดขาย 3"],
  "priceScript": "วิธีพูดถึงราคาที่น่าสนใจที่สุด เช่น เปรียบ value หรือพูดถึงส่วนลด",
  "hooks": [
    {"type":"Pain Hook 😱","script":"..."},
    {"type":"Result Hook ✨","script":"..."},
    {"type":"Secret Hook 🤫","script":"..."}
  ],
  "scripts": {
    "grwm": "สคริปต์ GRWM 5-6 ประโยค",
    "beforeAfter": "สคริปต์ Before&After 5-6 ประโยค",
    "tutorial": "สคริปต์ Tutorial 5-6 ประโยค",
    "review": "สคริปต์ Review 5-6 ประโยค"
  },
  "cta": [
    {"type":"Flash Sale ⏰","text":"..."},
    {"type":"Social Proof 👥","text":"..."},
    {"type":"Scarcity 📦","text":"..."}
  ],
  "repurchaseLine": "ประโยคกระตุ้นซื้อซ้ำ",
  "hashtags": "#แท็ก1 #แท็ก2 ... (12-15 แท็กที่เกี่ยวกับสินค้านี้จริงๆ)"
}`;

      const msgContent = imageContent
        ? [imageContent, { type: "text", text: userPrompt }]
        : [{ type: "text", text: userPrompt }];

      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: systemPrompt,
          messages: [{ role: "user", content: msgContent }]
        })
      });
      const data = await resp.json();
      const raw = data.content?.map(i => i.text || "").join("") || "";
      const clean = raw.replace(/```json|```/g, "").trim();
      setAiResult(JSON.parse(clean));
    } catch (e) {
      setAiResult({ error: "เกิดข้อผิดพลาด กรุณาลองใหม่" });
    }
    setLoading(false);
    setLoadingStep("");
  };

  const inputStyle = { width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:"10px", padding:"11px 13px", color:"#F0F0F0", fontSize:"14px", outline:"none", boxSizing:"border-box" };
  const labelStyle = { fontSize:"11px", color:"rgba(255,255,255,0.45)", letterSpacing:"1px", marginBottom:"5px", display:"block", textTransform:"uppercase" };

  // ── ADD VIEW ──
  if (view === "add") return (
    <div>
      <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"16px" }}>
        <button onClick={() => { setView("list"); setTiktokUrl(""); setImgFile(null); setImgPreview(null); setAnalyzed(null); }}
          style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#F0F0F0", borderRadius:"8px", padding:"6px 12px", cursor:"pointer", fontSize:"13px" }}>← กลับ</button>
        <div style={{ fontWeight:"700", fontSize:"16px" }}>เพิ่มสินค้าใหม่</div>
      </div>

      {/* Step indicator */}
      <div style={{ display:"flex", gap:"6px", marginBottom:"18px", padding:"12px 14px", background:"rgba(255,255,255,0.03)", borderRadius:"12px", border:"1px solid rgba(255,255,255,0.07)" }}>
        <StepBadge num="1" label="วางลิงก์" active={!tiktokUrl} done={!!tiktokUrl && isValidTikTokUrl(tiktokUrl)} />
        <div style={{ color:"rgba(255,255,255,0.2)", alignSelf:"center", fontSize:"12px" }}>›</div>
        <StepBadge num="2" label="แนบรูป" active={!!tiktokUrl && !imgFile} done={!!imgFile} />
        <div style={{ color:"rgba(255,255,255,0.2)", alignSelf:"center", fontSize:"12px" }}>›</div>
        <StepBadge num="3" label="วิเคราะห์" active={!!imgFile && !analyzed} done={!!analyzed && !analyzed.error} />
      </div>

      {/* Step 1: TikTok URL */}
      <div style={{ marginBottom:"14px" }}>
        <label style={labelStyle}>① ลิงก์สินค้า TikTok Shop</label>
        <div style={{ position:"relative" }}>
          <input
            style={{ ...inputStyle, paddingLeft:"38px", border: tiktokUrl && !isValidTikTokUrl(tiktokUrl) ? "1px solid #FF3B5C" : "1px solid rgba(255,255,255,0.12)" }}
            placeholder="https://www.tiktok.com/@shop/product/..."
            value={tiktokUrl}
            onChange={e => { setTiktokUrl(e.target.value); setAnalyzed(null); }}
          />
          <span style={{ position:"absolute", left:"12px", top:"50%", transform:"translateY(-50%)", fontSize:"16px" }}>🔗</span>
        </div>
        {tiktokUrl && !isValidTikTokUrl(tiktokUrl) && (
          <div style={{ fontSize:"11px", color:"#FF3B5C", marginTop:"4px" }}>⚠️ ลิงก์ต้องมาจาก tiktok.com เท่านั้น</div>
        )}
        {tiktokUrl && isValidTikTokUrl(tiktokUrl) && (
          <div style={{ fontSize:"11px", color:"#30D158", marginTop:"4px" }}>✓ ลิงก์ถูกต้อง</div>
        )}
        <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.3)", marginTop:"4px" }}>
          คัดลอกลิงก์จาก TikTok App → แชร์ → คัดลอกลิงก์
        </div>
      </div>

      {/* Step 2: Screenshot */}
      <div style={{ marginBottom:"14px" }}>
        <label style={labelStyle}>② Screenshot หน้าสินค้า TikTok</label>
        <div
          onClick={() => fileRef.current?.click()}
          style={{ border:`2px dashed ${imgPreview ? "rgba(48,209,88,0.5)" : "rgba(255,255,255,0.15)"}`, borderRadius:"14px", padding:"16px", textAlign:"center", cursor:"pointer", background: imgPreview ? "rgba(48,209,88,0.04)" : "rgba(255,255,255,0.02)", transition:"all 0.2s" }}
        >
          {imgPreview ? (
            <div>
              <img src={imgPreview} alt="" style={{ maxWidth:"100%", maxHeight:"200px", objectFit:"contain", borderRadius:"10px", display:"block", margin:"0 auto 8px" }} />
              <div style={{ fontSize:"11px", color:"#30D158" }}>✓ แนบรูปแล้ว — แตะเพื่อเปลี่ยน</div>
            </div>
          ) : (
            <div>
              <div style={{ fontSize:"36px", marginBottom:"6px" }}>📱</div>
              <div style={{ fontWeight:"700", fontSize:"14px", color:"rgba(255,255,255,0.7)", marginBottom:"4px" }}>แตะเพื่อแนบ Screenshot</div>
              <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.3)", lineHeight:"1.6" }}>
                Screnshot หน้าสินค้าใน TikTok<br />ที่เห็นชื่อ ราคา รูปสินค้าชัดเจน
              </div>
            </div>
          )}
          <input ref={fileRef} type="file" accept="image/*" style={{ display:"none" }} onChange={handleImagePick} />
        </div>
      </div>

      {/* Analyze Button */}
      <button
        onClick={handleAnalyze}
        disabled={!canAnalyze || analyzing}
        style={{ width:"100%", padding:"13px", borderRadius:"12px", border:"none", cursor: (!canAnalyze || analyzing) ? "not-allowed" : "pointer", background: (!canAnalyze || analyzing) ? "rgba(255,255,255,0.08)" : "linear-gradient(90deg,#FF6B35,#FF3B5C)", color: !canAnalyze ? "rgba(255,255,255,0.3)" : "#fff", fontWeight:"700", fontSize:"14px", marginBottom:"14px", transition:"all 0.2s" }}
      >
        {analyzing ? "⏳ กำลังวิเคราะห์..." : "🔍 วิเคราะห์สินค้าจากลิงก์ + รูป"}
      </button>

      {/* Analyzing spinner */}
      {analyzing && (
        <div style={{ background:"rgba(255,107,53,0.08)", border:"1px solid rgba(255,107,53,0.25)", borderRadius:"12px", padding:"14px", textAlign:"center", marginBottom:"14px" }}>
          <div style={{ fontSize:"22px", marginBottom:"6px", display:"inline-block", animation:"spin 1s linear infinite" }}>🔍</div>
          <div style={{ fontSize:"13px", color:"#FF6B35" }}>AI กำลังอ่านลิงก์ + วิเคราะห์รูปสินค้า<br />เพื่อหาข้อมูลที่แม่นยำที่สุด...</div>
          <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
        </div>
      )}

      {/* Analysis Result */}
      {analyzed && !analyzed.error && !analyzing && (
        <div style={{ background:"rgba(48,209,88,0.07)", border:"1px solid rgba(48,209,88,0.3)", borderRadius:"14px", padding:"14px", marginBottom:"14px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"12px" }}>
            <div style={{ fontWeight:"700", fontSize:"13px", color:"#30D158" }}>✅ วิเคราะห์สำเร็จ</div>
            <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.3)", background:"rgba(255,255,255,0.06)", padding:"3px 8px", borderRadius:"20px" }}>จาก URL + รูปภาพ</div>
          </div>

          {/* Main info grid */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"7px", marginBottom:"10px" }}>
            {[
              { label:"ชื่อสินค้า", val: analyzed.productName, span: true },
              { label:"แบรนด์", val: analyzed.brand || "ไม่ระบุ" },
              { label:"ร้านค้า", val: analyzed.shopName || "ไม่ระบุ" },
              { label:"หมวดหมู่", val: analyzed.category },
              { label:"ราคา", val: analyzed.priceRangeTHB ? `฿${analyzed.priceRangeTHB}` : "-" },
            ].map(({ label, val, span }) => (
              <div key={label} style={{ background:"rgba(255,255,255,0.05)", borderRadius:"8px", padding:"8px 10px", gridColumn: span ? "1 / -1" : "auto" }}>
                <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.35)", marginBottom:"2px", textTransform:"uppercase", letterSpacing:"0.5px" }}>{label}</div>
                <div style={{ fontSize:"13px", fontWeight:"600" }}>{val}</div>
              </div>
            ))}
          </div>

          {/* Price details */}
          {(analyzed.originalPrice || analyzed.discountPct || analyzed.rating || analyzed.soldCount) && (
            <div style={{ display:"flex", flexWrap:"wrap", gap:"6px", marginBottom:"10px" }}>
              {analyzed.originalPrice && <span style={{ background:"rgba(255,255,255,0.07)", borderRadius:"20px", padding:"3px 10px", fontSize:"11px", color:"rgba(255,255,255,0.5)" }}>ราคาเดิม ฿{analyzed.originalPrice}</span>}
              {analyzed.discountPct && <span style={{ background:"rgba(255,59,92,0.15)", border:"1px solid rgba(255,59,92,0.3)", borderRadius:"20px", padding:"3px 10px", fontSize:"11px", color:"#FF3B5C", fontWeight:"700" }}>ลด {analyzed.discountPct}%</span>}
              {analyzed.rating && <span style={{ background:"rgba(255,204,0,0.12)", borderRadius:"20px", padding:"3px 10px", fontSize:"11px", color:"#FFCC00" }}>⭐ {analyzed.rating}</span>}
              {analyzed.soldCount && <span style={{ background:"rgba(48,209,88,0.1)", borderRadius:"20px", padding:"3px 10px", fontSize:"11px", color:"#30D158" }}>ขายแล้ว {analyzed.soldCount}</span>}
            </div>
          )}

          {analyzed.keyBenefits?.length > 0 && (
            <div style={{ marginBottom:"8px" }}>
              <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.35)", marginBottom:"5px", textTransform:"uppercase" }}>สรรพคุณหลัก</div>
              <div style={{ display:"flex", flexWrap:"wrap", gap:"5px" }}>
                {analyzed.keyBenefits.map((b, i) => (
                  <span key={i} style={{ background:"rgba(255,107,53,0.15)", border:"1px solid rgba(255,107,53,0.25)", borderRadius:"20px", padding:"3px 10px", fontSize:"11px", color:"#FF6B35" }}>{b}</span>
                ))}
              </div>
            </div>
          )}

          {analyzed.complianceFlags?.length > 0 && (
            <div style={{ background:"rgba(255,204,0,0.07)", border:"1px solid rgba(255,204,0,0.25)", borderRadius:"8px", padding:"8px 10px" }}>
              <div style={{ fontSize:"11px", color:"#FFCC00", fontWeight:"700", marginBottom:"4px" }}>⚠️ ข้อควรระวัง TikTok Policy</div>
              {analyzed.complianceFlags.map((f, i) => (
                <div key={i} style={{ fontSize:"11px", color:"rgba(255,204,0,0.8)", marginBottom:"2px" }}>• {f}</div>
              ))}
            </div>
          )}
        </div>
      )}

      {analyzed?.error && (
        <div style={{ background:"rgba(255,59,92,0.1)", border:"1px solid rgba(255,59,92,0.3)", borderRadius:"12px", padding:"12px", textAlign:"center", color:"#FF3B5C", fontSize:"13px", marginBottom:"14px" }}>
          ❌ {analyzed.error}
        </div>
      )}

      <button
        onClick={saveProduct}
        disabled={!analyzed || !!analyzed.error || analyzing}
        style={{ width:"100%", padding:"14px", borderRadius:"12px", border:"none", cursor:(!analyzed || !!analyzed.error || analyzing) ? "not-allowed" : "pointer", background:(!analyzed || !!analyzed.error || analyzing) ? "rgba(255,255,255,0.08)" : "linear-gradient(90deg,#FF3B5C,#7B2FBE)", color: (!analyzed || !!analyzed.error) ? "rgba(255,255,255,0.3)" : "#fff", fontWeight:"700", fontSize:"15px" }}
      >
        {analyzing ? "⏳ กำลังวิเคราะห์..." : !analyzed ? "⏳ รอวิเคราะห์ก่อน" : "✅ บันทึกสินค้า"}
      </button>
    </div>
  );

  // ── RESULT VIEW ──
  if (view === "result") return (
    <div>
      <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"16px" }}>
        <button onClick={() => { setView("list"); setAiResult(null); }} style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#F0F0F0", borderRadius:"8px", padding:"6px 12px", cursor:"pointer", fontSize:"13px" }}>← กลับ</button>
        <div style={{ fontWeight:"700", fontSize:"15px", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{selectedProduct?.productName}</div>
      </div>

      {/* Product card */}
      <div style={{ background:"rgba(255,255,255,0.04)", borderRadius:"14px", padding:"12px", marginBottom:"16px", border:"1px solid rgba(255,255,255,0.08)" }}>
        <div style={{ display:"flex", gap:"12px", marginBottom: selectedProduct?.tiktokUrl ? "10px" : "0" }}>
          {selectedProduct?.imgPreview
            ? <img src={selectedProduct.imgPreview} alt="" style={{ width:"72px", height:"72px", objectFit:"cover", borderRadius:"10px", flexShrink:0 }} />
            : <div style={{ width:"72px", height:"72px", background:"rgba(255,255,255,0.06)", borderRadius:"10px", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"28px", flexShrink:0 }}>💄</div>
          }
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontWeight:"700", fontSize:"15px" }}>{selectedProduct?.productName}</div>
            {selectedProduct?.brand && <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.5)" }}>{selectedProduct.brand}{selectedProduct?.shopName ? ` · ${selectedProduct.shopName}` : ""}</div>}
            <div style={{ display:"flex", alignItems:"center", gap:"8px", marginTop:"3px", flexWrap:"wrap" }}>
              <div style={{ color:"#FF3B5C", fontWeight:"800", fontSize:"17px" }}>฿{selectedProduct?.priceRangeTHB}</div>
              {selectedProduct?.originalPrice && <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.35)", textDecoration:"line-through" }}>฿{selectedProduct.originalPrice}</div>}
              {selectedProduct?.discountPct && <div style={{ background:"rgba(255,59,92,0.2)", color:"#FF3B5C", fontSize:"11px", fontWeight:"700", padding:"2px 7px", borderRadius:"20px" }}>-{selectedProduct.discountPct}%</div>}
            </div>
            <div style={{ display:"flex", gap:"6px", marginTop:"3px", flexWrap:"wrap" }}>
              {selectedProduct?.rating && <span style={{ fontSize:"11px", color:"#FFCC00" }}>⭐ {selectedProduct.rating}</span>}
              {selectedProduct?.soldCount && <span style={{ fontSize:"11px", color:"#30D158" }}>· ขาย {selectedProduct.soldCount}</span>}
            </div>
          </div>
        </div>
        {selectedProduct?.tiktokUrl && (
          <div style={{ background:"rgba(255,255,255,0.04)", borderRadius:"8px", padding:"7px 10px", display:"flex", alignItems:"center", gap:"7px" }}>
            <span style={{ fontSize:"13px" }}>🔗</span>
            <span style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{selectedProduct.tiktokUrl}</span>
          </div>
        )}
      </div>

      {loading && (
        <div style={{ textAlign:"center", padding:"40px 20px" }}>
          <div style={{ fontSize:"36px", marginBottom:"12px", display:"inline-block", animation:"spin 1s linear infinite" }}>⚙️</div>
          <div style={{ color:"rgba(255,255,255,0.6)", fontSize:"13px", lineHeight:"1.8" }}>{loadingStep || "กำลังประมวลผล..."}</div>
          <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
        </div>
      )}

      {aiResult?.error && <div style={{ background:"rgba(255,59,92,0.1)", border:"1px solid rgba(255,59,92,0.3)", borderRadius:"12px", padding:"16px", textAlign:"center", color:"#FF3B5C" }}>{aiResult.error}</div>}

      {aiResult && !aiResult.error && (
        <div>
          {/* Compliance Badge */}
          <div style={{ background: aiResult.complianceStatus === "PASS" ? "rgba(48,209,88,0.1)" : "rgba(255,204,0,0.1)", border:`1px solid ${aiResult.complianceStatus === "PASS" ? "rgba(48,209,88,0.35)" : "rgba(255,204,0,0.35)"}`, borderRadius:"12px", padding:"10px 14px", marginBottom:"12px", display:"flex", gap:"10px", alignItems:"flex-start" }}>
            <span style={{ fontSize:"20px", flexShrink:0 }}>{aiResult.complianceStatus === "PASS" ? "✅" : "⚠️"}</span>
            <div>
              <div style={{ fontWeight:"700", fontSize:"12px", color: aiResult.complianceStatus === "PASS" ? "#30D158" : "#FFCC00" }}>
                {aiResult.complianceStatus === "PASS" ? "ผ่าน TikTok Compliance Check" : "ระวัง — ตรวจสอบก่อนโพสต์"}
              </div>
              <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.6)", marginTop:"2px" }}>{aiResult.complianceNote}</div>
            </div>
          </div>

          <SectionCard title="📌 จุดขายหลัก" color="#FF3B5C">
            <div style={{ fontSize:"13px", lineHeight:"1.8", color:"rgba(255,255,255,0.85)", marginBottom:"8px" }}>{aiResult.productSummary}</div>
            {aiResult.keySellingPoints?.map((pt, i) => (
              <div key={i} style={{ display:"flex", gap:"8px", marginBottom:"4px", fontSize:"13px" }}>
                <span style={{ color:"#FF3B5C", fontWeight:"700" }}>✦</span><span>{pt}</span>
              </div>
            ))}
            {aiResult.estimatedPrice && (
              <div style={{ marginTop:"8px", background:"rgba(255,59,92,0.1)", borderRadius:"8px", padding:"6px 10px", fontSize:"12px", color:"#FF6B35" }}>
                💰 ราคาแนะนำในคอนเทนต์: <strong>{aiResult.estimatedPrice}</strong>
              </div>
            )}
          </SectionCard>

          <SectionCard title="🎣 Hook 3 วิ (3 แบบ)" color="#FF6B35">
            {aiResult.hooks?.map((h, i) => (
              <CopyBlock key={i} label={h.type} text={h.script} id={`ah-${i}`} copiedId={copiedId} onCopy={copyText} color="#FF6B35" />
            ))}
          </SectionCard>

          <SectionCard title="🎬 สคริปต์ตามแนวเนื้อหา" color="#0A84FF">
            {[{ key:"grwm", label:"💄 GRWM" },{ key:"beforeAfter", label:"🔄 Before & After" },{ key:"tutorial", label:"📋 Tutorial" },{ key:"review", label:"📦 Review" }].map(({ key, label }) =>
              aiResult.scripts?.[key] && <CopyBlock key={key} label={label} text={aiResult.scripts[key]} id={`as-${key}`} copiedId={copiedId} onCopy={copyText} color="#0A84FF" />
            )}
          </SectionCard>

          <SectionCard title="🛒 CTA ปรับตามสินค้า" color="#7B2FBE">
            {aiResult.cta?.map((c, i) => (
              <CopyBlock key={i} label={c.type} text={c.text} id={`ac-${i}`} copiedId={copiedId} onCopy={copyText} color="#7B2FBE" />
            ))}
            {aiResult.repurchaseLine && (
              <CopyBlock label="🔄 Repurchase Line" text={aiResult.repurchaseLine} id="arp" copiedId={copiedId} onCopy={copyText} color="#A855F7" />
            )}
          </SectionCard>

          <SectionCard title="#️⃣ Hashtag ชุดเต็ม" color="#30D158">
            <div style={{ fontSize:"13px", lineHeight:"2.1", color:"rgba(255,255,255,0.8)", marginBottom:"10px" }}>{aiResult.hashtags}</div>
            <button onClick={() => copyText(aiResult.hashtags, "ah-tags")}
              style={{ width:"100%", padding:"10px", borderRadius:"10px", border:"1px solid rgba(48,209,88,0.4)", background: copiedId==="ah-tags" ? "#30D158" : "rgba(48,209,88,0.15)", color: copiedId==="ah-tags" ? "#000" : "#30D158", fontWeight:"700", fontSize:"13px", cursor:"pointer" }}>
              {copiedId==="ah-tags" ? "✅ Copied!" : "📋 Copy Hashtag ทั้งหมด"}
            </button>
          </SectionCard>

          <ClipAnalyzerSection product={selectedProduct} />
        </div>
      )}
    </div>
  );

  // ── LIST VIEW ──
  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"14px" }}>
        <div>
          <div style={{ fontWeight:"700", fontSize:"16px" }}>สินค้าของฉัน</div>
          <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.4)" }}>{products.length} รายการ</div>
        </div>
        <button onClick={() => setView("add")} style={{ background:"linear-gradient(90deg,#FF3B5C,#7B2FBE)", border:"none", color:"#fff", borderRadius:"10px", padding:"9px 16px", fontWeight:"700", fontSize:"13px", cursor:"pointer" }}>
          + เพิ่มสินค้า
        </button>
      </div>

      {products.length === 0 && (
        <div style={{ textAlign:"center", padding:"40px 20px", color:"rgba(255,255,255,0.25)" }}>
          <div style={{ fontSize:"48px", marginBottom:"12px" }}>📱</div>
          <div style={{ fontSize:"14px", marginBottom:"6px" }}>ยังไม่มีสินค้า</div>
          <div style={{ fontSize:"12px", lineHeight:"1.8" }}>กด "+ เพิ่มสินค้า"<br/>วางลิงก์ TikTok + แนบ Screenshot<br/>AI จะวิเคราะห์ข้อมูลให้ครบอัตโนมัติ</div>
        </div>
      )}

      {products.map(product => (
        <div key={product.id} style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"14px", padding:"12px", marginBottom:"10px" }}>
          <div style={{ display:"flex", gap:"12px", alignItems:"flex-start" }}>
            {product.imgPreview
              ? <img src={product.imgPreview} alt="" style={{ width:"60px", height:"60px", objectFit:"cover", borderRadius:"10px", flexShrink:0 }} />
              : <div style={{ width:"60px", height:"60px", background:"rgba(255,255,255,0.06)", borderRadius:"10px", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"22px", flexShrink:0 }}>💄</div>
            }
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontWeight:"700", fontSize:"14px", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{product.productName}</div>
              {product.brand && <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)" }}>{product.brand}{product.shopName ? " · " + product.shopName : ""}</div>}
              <div style={{ display:"flex", alignItems:"center", gap:"6px", marginTop:"3px", flexWrap:"wrap" }}>
                <span style={{ color:"#FF3B5C", fontWeight:"800", fontSize:"15px" }}>฿{product.priceRangeTHB}</span>
                {product.discountPct && <span style={{ background:"rgba(255,59,92,0.2)", color:"#FF3B5C", fontSize:"10px", fontWeight:"700", padding:"1px 6px", borderRadius:"20px" }}>-{product.discountPct}%</span>}
                {product.rating && <span style={{ fontSize:"11px", color:"#FFCC00" }}>⭐{product.rating}</span>}
                {product.soldCount && <span style={{ fontSize:"11px", color:"#30D158" }}>ขาย {product.soldCount}</span>}
              </div>
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:"6px", flexShrink:0 }}>
              <button onClick={() => generateContent(product)} style={{ background:"linear-gradient(90deg,#FF3B5C,#7B2FBE)", border:"none", color:"#fff", borderRadius:"8px", padding:"8px 12px", fontWeight:"700", fontSize:"12px", cursor:"pointer", whiteSpace:"nowrap" }}>
                ✨ Gen
              </button>
              <button onClick={() => setProducts(p => p.filter(x => x.id !== product.id))} style={{ background:"rgba(255,59,92,0.1)", border:"1px solid rgba(255,59,92,0.2)", color:"rgba(255,59,92,0.8)", borderRadius:"8px", padding:"5px 12px", fontSize:"11px", cursor:"pointer" }}>
                ลบ
              </button>
            </div>
          </div>
          {product.tiktokUrl && (
            <div style={{ marginTop:"8px", background:"rgba(255,255,255,0.03)", borderRadius:"8px", padding:"6px 10px", display:"flex", alignItems:"center", gap:"6px" }}>
              <span style={{ fontSize:"12px" }}>🔗</span>
              <span style={{ fontSize:"10px", color:"rgba(255,255,255,0.35)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{product.tiktokUrl}</span>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function SectionCard({ title, color, children }) {
  return (
    <div style={{ background:"rgba(255,255,255,0.03)", border:`1px solid ${color}33`, borderRadius:"14px", padding:"14px", marginBottom:"12px" }}>
      <div style={{ fontWeight:"700", fontSize:"13px", color, marginBottom:"10px" }}>{title}</div>
      {children}
    </div>
  );
}

function CopyBlock({ label, text, id, copiedId, onCopy, color }) {
  return (
    <div style={{ marginBottom:"8px" }}>
      <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"4px" }}>{label}</div>
      <div onClick={() => onCopy(text, id)} style={{ background:"rgba(0,0,0,0.3)", border:`1px solid ${color}33`, borderRadius:"10px", padding:"10px 12px", fontSize:"13px", lineHeight:"1.7", cursor:"pointer", display:"flex", justifyContent:"space-between", gap:"8px" }}>
        <span style={{ flex:1 }}>{text}</span>
        <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId === id ? "✅" : "📋"}</span>
      </div>
    </div>
  );
}



// ═══════════════════════════════════════════════
//  CLIP ANALYZER SECTION (embedded in Product page)
// ═══════════════════════════════════════════════
function ClipAnalyzerSection({ product }) {
  const [clips, setClips] = useState([]); // [{id, file, url, name, preview, status, analysis}]
  const [analyzing, setAnalyzing] = useState(false);
  const [loadMsg, setLoadMsg] = useState("");
  const [synthesis, setSynthesis] = useState(null);
  const [activeClip, setActiveClip] = useState(null);
  const [copiedId, setCopiedId] = useState(null);
  const videoRef = useRef();

  const MAX_CLIPS = 5;
  const copyText = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handleClipAdd = (e) => {
    const files = Array.from(e.target.files || []);
    const remaining = MAX_CLIPS - clips.length;
    const toAdd = files.slice(0, remaining).map(f => ({
      id: Date.now() + Math.random(),
      file: f,
      url: "",
      name: f.name.replace(/\.[^.]+$/, ""),
      preview: URL.createObjectURL(f),
      status: "ready",
      analysis: null,
    }));
    setClips(prev => [...prev, ...toAdd]);
    setSynthesis(null);
  };

  const removeClip = (id) => {
    setClips(prev => prev.filter(c => c.id !== id));
    if (activeClip?.id === id) setActiveClip(null);
    setSynthesis(null);
  };

  const updateClipUrl = (id, url) => {
    setClips(prev => prev.map(c => c.id === id ? { ...c, url } : c));
  };

  const analyzeAll = async () => {
    if (!clips.length) return;
    setAnalyzing(true);
    setSynthesis(null);
    setActiveClip(null);

    const productContext = `${product.productName} (${product.category}) ราคา ฿${product.priceRangeTHB}`;
    const results = [];

    for (let i = 0; i < clips.length; i++) {
      const clip = clips[i];
      setLoadMsg(`🎬 วิเคราะห์คลิปที่ ${i+1}/${clips.length}: ${clip.name}...`);
      setClips(prev => prev.map(c => c.id === clip.id ? { ...c, status: "analyzing" } : c));

      try {
        setLoadMsg(`📹 สกัด frame จากคลิป ${i+1}...`);
        const frames = await sampleVideoFrames(clip.file, 6);
        setLoadMsg(`🤖 AI วิเคราะห์โครงสร้างคลิป ${i+1}...`);
        const analysis = await analyzeClipWithAI(clip.name, clip.url, frames, productContext);
        results.push({ ...clip, analysis });
        setClips(prev => prev.map(c => c.id === clip.id ? { ...c, status: "done", analysis } : c));
      } catch (e) {
        results.push({ ...clip, analysis: null });
        setClips(prev => prev.map(c => c.id === clip.id ? { ...c, status: "error" } : c));
      }
    }

    if (results.filter(r => r.analysis).length > 0) {
      setLoadMsg("🧠 สังเคราะห์ GMV-Max Structure จากทุกคลิป...");
      try {
        const syn = await synthesizeClipInsights(results.filter(r => r.analysis), productContext);
        setSynthesis(syn);
        setActiveClip(results.find(r => r.analysis) || null);
      } catch(e) { setSynthesis({ error: "สรุปไม่ได้" }); }
    }

    setAnalyzing(false);
    setLoadMsg("");
  };

  const gmvColor = (score) => score >= 80 ? "#30D158" : score >= 60 ? "#FF6B35" : "#FF3B5C";
  const strengthColor = { Strong: "#30D158", Medium: "#FF6B35", Weak: "#FF3B5C" };
  const impactColor = { High: "#30D158", Med: "#FF6B35", Low: "rgba(255,255,255,0.3)" };

  return (
    <div style={{ marginTop: "20px" }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"12px" }}>
        <div style={{ flex:1 }}>
          <div style={{ fontWeight:"800", fontSize:"15px" }}>🎬 วิเคราะห์คลิปตัวอย่าง</div>
          <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginTop:"2px" }}>
            อัปโหลด Screen-record สูงสุด {MAX_CLIPS} คลิป → AI วิเคราะห์ GMV-Max Structure
          </div>
        </div>
        <div style={{ background:"rgba(255,204,0,0.12)", color:"#FFCC00", fontSize:"11px", fontWeight:"700", padding:"4px 10px", borderRadius:"20px" }}>
          {clips.length}/{MAX_CLIPS}
        </div>
      </div>

      {/* Clip list */}
      {clips.map((clip, i) => (
        <div key={clip.id} style={{
          background: activeClip?.id === clip.id ? "rgba(255,59,92,0.08)" : "rgba(255,255,255,0.03)",
          border: `1px solid ${activeClip?.id === clip.id ? "rgba(255,59,92,0.35)" : "rgba(255,255,255,0.08)"}`,
          borderRadius:"12px", padding:"10px 12px", marginBottom:"8px",
        }}>
          <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
            {/* Thumbnail */}
            <video src={clip.preview} style={{ width:"48px", height:"72px", objectFit:"cover", borderRadius:"8px", flexShrink:0, background:"#000" }} muted />

            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:"13px", fontWeight:"600", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                {clip.status === "analyzing" ? <span style={{ color:"#FF6B35" }}>⏳ กำลังวิเคราะห์...</span>
                  : clip.status === "done" ? <span style={{ color:"#30D158" }}>✅ </span>
                  : clip.status === "error" ? <span style={{ color:"#FF3B5C" }}>❌ </span>
                  : "📹 "}
                {clip.name}
              </div>
              {/* URL input */}
              <input
                style={{ width:"100%", background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"6px", padding:"4px 8px", color:"rgba(255,255,255,0.7)", fontSize:"11px", outline:"none", marginTop:"5px", boxSizing:"border-box" }}
                placeholder="ลิงก์ TikTok คลิปนี้ (ไม่บังคับ)"
                value={clip.url}
                onChange={e => updateClipUrl(clip.id, e.target.value)}
              />
              {/* GMV score chip if done */}
              {clip.analysis?.gmvScore && (
                <div style={{ display:"flex", gap:"6px", marginTop:"5px", flexWrap:"wrap" }}>
                  <span style={{ background:`${gmvColor(clip.analysis.gmvScore)}22`, color:gmvColor(clip.analysis.gmvScore), fontSize:"11px", fontWeight:"700", padding:"2px 8px", borderRadius:"20px", border:`1px solid ${gmvColor(clip.analysis.gmvScore)}44` }}>
                    GMV {clip.analysis.gmvScore}
                  </span>
                  <span style={{ background:"rgba(255,255,255,0.06)", fontSize:"11px", padding:"2px 8px", borderRadius:"20px", color:"rgba(255,255,255,0.5)" }}>{clip.analysis.contentType}</span>
                  <span style={{ background:"rgba(255,255,255,0.06)", fontSize:"11px", padding:"2px 8px", borderRadius:"20px", color:"rgba(255,255,255,0.5)" }}>Hook: {clip.analysis.hookAnalysis?.hookType}</span>
                </div>
              )}
            </div>

            <div style={{ display:"flex", flexDirection:"column", gap:"5px", flexShrink:0 }}>
              {clip.status === "done" && (
                <button onClick={() => setActiveClip(activeClip?.id === clip.id ? null : clip)}
                  style={{ background:"rgba(255,59,92,0.15)", border:"1px solid rgba(255,59,92,0.3)", color:"#FF3B5C", borderRadius:"7px", padding:"5px 9px", fontSize:"11px", fontWeight:"700", cursor:"pointer" }}>
                  {activeClip?.id === clip.id ? "ปิด" : "ดู"}
                </button>
              )}
              <button onClick={() => removeClip(clip.id)}
                style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", color:"rgba(255,255,255,0.4)", borderRadius:"7px", padding:"5px 9px", fontSize:"11px", cursor:"pointer" }}>
                ✕
              </button>
            </div>
          </div>

          {/* Expanded clip detail */}
          {activeClip?.id === clip.id && clip.analysis && (() => {
            const a = clip.analysis;
            return (
              <div style={{ marginTop:"12px", paddingTop:"12px", borderTop:"1px solid rgba(255,255,255,0.07)" }}>
                {/* GMV breakdown bars */}
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"6px", marginBottom:"12px" }}>
                  {[
                    { label:"Hook", val:a.gmvBreakdown?.hookScore },
                    { label:"Demo", val:a.gmvBreakdown?.demoScore },
                    { label:"CTA", val:a.gmvBreakdown?.ctaScore },
                    { label:"Trust", val:a.gmvBreakdown?.trustScore },
                  ].map(({ label, val }) => (
                    <div key={label} style={{ background:"rgba(255,255,255,0.04)", borderRadius:"8px", padding:"8px 10px" }}>
                      <div style={{ display:"flex", justifyContent:"space-between", fontSize:"11px", marginBottom:"4px" }}>
                        <span style={{ color:"rgba(255,255,255,0.5)" }}>{label}</span>
                        <span style={{ color:gmvColor(val||0), fontWeight:"700" }}>{val||"-"}</span>
                      </div>
                      <div style={{ height:"5px", background:"rgba(255,255,255,0.07)", borderRadius:"3px" }}>
                        <div style={{ height:"100%", width:`${val||0}%`, background:gmvColor(val||0), borderRadius:"3px" }} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Hook */}
                <div style={{ background:"rgba(255,59,92,0.08)", border:"1px solid rgba(255,59,92,0.2)", borderRadius:"10px", padding:"10px 12px", marginBottom:"8px" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"5px" }}>
                    <span style={{ fontSize:"11px", fontWeight:"700", color:"#FF3B5C" }}>🎣 Hook · {a.hookAnalysis?.hookType}</span>
                    <span style={{ fontSize:"10px", color:strengthColor[a.hookAnalysis?.hookStrength], fontWeight:"700" }}>{a.hookAnalysis?.hookStrength}</span>
                  </div>
                  <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.8)", marginBottom:"4px", fontStyle:"italic" }}>"{a.hookAnalysis?.hookScript}"</div>
                  <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.45)" }}>{a.hookAnalysis?.hookReason}</div>
                </div>

                {/* Script structure timeline */}
                <div style={{ marginBottom:"8px" }}>
                  <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"6px", letterSpacing:"1px" }}>SCRIPT STRUCTURE</div>
                  {a.scriptStructure?.map((s, si) => (
                    <div key={si} style={{ display:"flex", gap:"8px", marginBottom:"5px", alignItems:"flex-start" }}>
                      <div style={{ background:"rgba(255,255,255,0.06)", borderRadius:"6px", padding:"2px 7px", fontSize:"10px", color:"rgba(255,255,255,0.5)", flexShrink:0, minWidth:"44px", textAlign:"center" }}>{s.second}</div>
                      <div style={{ flex:1 }}>
                        <span style={{ fontSize:"11px", fontWeight:"700", color:"#FF6B35" }}>{s.element}: </span>
                        <span style={{ fontSize:"11px", color:"rgba(255,255,255,0.7)" }}>{s.description}</span>
                      </div>
                      <div style={{ fontSize:"10px", fontWeight:"700", color:impactColor[s.gmvImpact], flexShrink:0 }}>{s.gmvImpact}</div>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <div style={{ background:"rgba(123,47,190,0.08)", border:"1px solid rgba(123,47,190,0.2)", borderRadius:"10px", padding:"10px 12px", marginBottom:"8px" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"5px" }}>
                    <span style={{ fontSize:"11px", fontWeight:"700", color:"#A855F7" }}>🛒 CTA · {a.ctaAnalysis?.ctaType}</span>
                    <span style={{ fontSize:"10px", color:strengthColor[a.ctaAnalysis?.ctaStrength], fontWeight:"700" }}>{a.ctaAnalysis?.ctaStrength}</span>
                  </div>
                  <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.8)", marginBottom:"4px", fontStyle:"italic" }}>"{a.ctaAnalysis?.ctaScript}"</div>
                  <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.45)" }}>Timing: {a.ctaAnalysis?.ctaPlacement}</div>
                </div>

                {/* Strengths & weaknesses */}
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"6px", marginBottom:"8px" }}>
                  <div style={{ background:"rgba(48,209,88,0.07)", border:"1px solid rgba(48,209,88,0.2)", borderRadius:"8px", padding:"8px 10px" }}>
                    <div style={{ fontSize:"11px", color:"#30D158", fontWeight:"700", marginBottom:"5px" }}>✅ จุดแข็ง</div>
                    {a.strengths?.map((s, si) => <div key={si} style={{ fontSize:"11px", color:"rgba(255,255,255,0.7)", marginBottom:"3px" }}>· {s}</div>)}
                  </div>
                  <div style={{ background:"rgba(255,59,92,0.07)", border:"1px solid rgba(255,59,92,0.2)", borderRadius:"8px", padding:"8px 10px" }}>
                    <div style={{ fontSize:"11px", color:"#FF3B5C", fontWeight:"700", marginBottom:"5px" }}>⚠️ จุดอ่อน</div>
                    {a.weaknesses?.map((w, wi) => <div key={wi} style={{ fontSize:"11px", color:"rgba(255,255,255,0.7)", marginBottom:"3px" }}>· {w}</div>)}
                  </div>
                </div>

                {/* Improvements */}
                <div style={{ background:"rgba(255,204,0,0.07)", border:"1px solid rgba(255,204,0,0.2)", borderRadius:"8px", padding:"8px 10px", marginBottom:"8px" }}>
                  <div style={{ fontSize:"11px", color:"#FFCC00", fontWeight:"700", marginBottom:"5px" }}>💡 ปรับเพื่อเพิ่ม GMV</div>
                  {a.improvements?.map((imp, ii) => (
                    <div key={ii} style={{ display:"flex", gap:"6px", marginBottom:"4px", fontSize:"11px", color:"rgba(255,255,255,0.75)" }}>
                      <span style={{ color:"#FFCC00", flexShrink:0 }}>{ii+1}.</span>{imp}
                    </div>
                  ))}
                </div>

                {/* Hashtags */}
                <div
                  onClick={() => copyText(a.hashtags, `hash-${clip.id}`)}
                  style={{ background:"rgba(10,132,255,0.08)", border:"1px solid rgba(10,132,255,0.2)", borderRadius:"8px", padding:"8px 12px", cursor:"pointer", display:"flex", justifyContent:"space-between", gap:"8px" }}
                >
                  <div>
                    <div style={{ fontSize:"11px", color:"#0A84FF", fontWeight:"700", marginBottom:"3px" }}>#️⃣ Hashtag สำหรับคลิปนี้</div>
                    <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.6)", lineHeight:"1.7" }}>{a.hashtags}</div>
                  </div>
                  <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId===`hash-${clip.id}` ? "✅" : "📋"}</span>
                </div>
              </div>
            );
          })()}
        </div>
      ))}

      {/* Add clip button */}
      {clips.length < MAX_CLIPS && (
        <div>
          <label style={{ display:"block", border:"2px dashed rgba(255,255,255,0.12)", borderRadius:"12px", padding:"14px", textAlign:"center", cursor:"pointer", background:"rgba(255,255,255,0.02)", marginBottom:"10px" }}>
            <div style={{ fontSize:"24px", marginBottom:"4px" }}>🎬</div>
            <div style={{ fontSize:"13px", fontWeight:"600", color:"rgba(255,255,255,0.6)" }}>
              + เพิ่มคลิป Screen-record (.mp4)
            </div>
            <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.3)", marginTop:"3px" }}>
              เหลืออีก {MAX_CLIPS - clips.length} คลิป · MP4 / MOV / WEBM
            </div>
            <input type="file" accept="video/*" multiple style={{ display:"none" }} onChange={handleClipAdd} />
          </label>
        </div>
      )}

      {/* Analyze button */}
      {clips.length > 0 && !analyzing && !synthesis && (
        <button
          onClick={analyzeAll}
          style={{ width:"100%", padding:"14px", borderRadius:"12px", border:"none", cursor:"pointer", background:"linear-gradient(90deg,#FF3B5C,#FF6B35,#7B2FBE)", color:"#fff", fontWeight:"800", fontSize:"15px", boxShadow:"0 4px 20px rgba(255,59,92,0.35)" }}
        >
          🎬 วิเคราะห์ {clips.length} คลิป → GMV-Max Structure
        </button>
      )}

      {/* Loading */}
      {analyzing && (
        <div style={{ textAlign:"center", padding:"20px", background:"rgba(255,255,255,0.03)", borderRadius:"12px", border:"1px solid rgba(255,255,255,0.07)" }}>
          <div style={{ fontSize:"28px", marginBottom:"8px", display:"inline-block", animation:"spin 1s linear infinite" }}>🎬</div>
          <div style={{ fontSize:"13px", color:"rgba(255,255,255,0.7)", fontWeight:"600" }}>{loadMsg}</div>
          <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
        </div>
      )}

      {/* Synthesis result */}
      {synthesis && !synthesis.error && (
        <div style={{ marginTop:"14px" }}>
          <div style={{ background:"linear-gradient(135deg,rgba(255,59,92,0.12),rgba(123,47,190,0.12))", border:"1px solid rgba(255,59,92,0.25)", borderRadius:"14px", padding:"14px", marginBottom:"12px" }}>
            <div style={{ display:"flex", alignItems:"center", gap:"12px", marginBottom:"12px" }}>
              <div style={{ textAlign:"center" }}>
                <div style={{ fontSize:"32px", fontWeight:"900", background:"linear-gradient(135deg,#FF3B5C,#7B2FBE)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>{synthesis.overallGMVScore}</div>
                <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.4)" }}>Overall GMV</div>
              </div>
              <div>
                <div style={{ fontWeight:"800", fontSize:"14px", marginBottom:"3px" }}>GMV-Max Blueprint</div>
                <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.5)" }}>สังเคราะห์จาก {clips.length} คลิป</div>
              </div>
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"7px", marginBottom:"10px" }}>
              {[
                { label:"Best Hook", val:synthesis.dominantHook, color:"#FF3B5C" },
                { label:"Best CTA", val:synthesis.dominantCTA, color:"#7B2FBE" },
              ].map(({ label, val, color }) => (
                <div key={label} style={{ background:"rgba(255,255,255,0.04)", borderRadius:"8px", padding:"8px 10px" }}>
                  <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.4)", marginBottom:"3px" }}>{label}</div>
                  <div style={{ fontSize:"12px", fontWeight:"700", color }}>{val}</div>
                </div>
              ))}
            </div>

            <div style={{ background:"rgba(255,204,0,0.08)", border:"1px solid rgba(255,204,0,0.2)", borderRadius:"10px", padding:"10px 12px", marginBottom:"10px" }}>
              <div style={{ fontSize:"11px", color:"#FFCC00", fontWeight:"700", marginBottom:"4px" }}>🏆 Winning Formula</div>
              <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.8)", lineHeight:"1.7" }}>{synthesis.winningFormula}</div>
            </div>
          </div>

          {/* GMV-Max Structure Timeline */}
          <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"14px", padding:"14px", marginBottom:"12px" }}>
            <div style={{ fontWeight:"700", fontSize:"13px", color:"#FF6B35", marginBottom:"10px" }}>⚡ GMV-Max Script Structure</div>
            {synthesis.gmvMaxStructure?.map((s, i) => (
              <div key={i} style={{ display:"flex", gap:"10px", marginBottom:"10px", alignItems:"flex-start" }}>
                <div style={{ background:"linear-gradient(135deg,#FF3B5C,#7B2FBE)", color:"#fff", borderRadius:"8px", padding:"4px 8px", fontSize:"11px", fontWeight:"700", flexShrink:0, minWidth:"48px", textAlign:"center" }}>{s.second}</div>
                <div style={{ flex:1, background:"rgba(255,255,255,0.03)", borderRadius:"8px", padding:"8px 10px" }}>
                  <div style={{ fontSize:"12px", fontWeight:"700", color:"#FF6B35", marginBottom:"3px" }}>{s.action}</div>
                  <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.8)", fontStyle:"italic", marginBottom:"3px" }}>"{s.example}"</div>
                  <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)" }}>💡 {s.why}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Best script template */}
          <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"14px", padding:"14px", marginBottom:"12px" }}>
            <div style={{ fontWeight:"700", fontSize:"13px", color:"#30D158", marginBottom:"10px" }}>📝 Best Script Template</div>
            {synthesis.bestScriptTemplate && Object.entries(synthesis.bestScriptTemplate).map(([key, val]) => (
              <div
                key={key}
                onClick={() => copyText(val, `tpl-${key}`)}
                style={{ background:"rgba(255,255,255,0.04)", borderRadius:"8px", padding:"8px 10px", marginBottom:"7px", cursor:"pointer", display:"flex", gap:"8px", justifyContent:"space-between" }}
              >
                <div>
                  <div style={{ fontSize:"10px", color:"#30D158", fontWeight:"700", marginBottom:"3px", textTransform:"uppercase" }}>{key}</div>
                  <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.8)", lineHeight:"1.6" }}>{val}</div>
                </div>
                <span style={{ fontSize:"15px", flexShrink:0 }}>{copiedId===`tpl-${key}` ? "✅" : "📋"}</span>
              </div>
            ))}
          </div>

          {/* Hashtags */}
          <div
            onClick={() => copyText(synthesis.topHashtags, "syn-hash")}
            style={{ background:"rgba(10,132,255,0.08)", border:"1px solid rgba(10,132,255,0.25)", borderRadius:"12px", padding:"12px 14px", cursor:"pointer", display:"flex", gap:"10px", justifyContent:"space-between", marginBottom:"10px" }}
          >
            <div>
              <div style={{ fontSize:"11px", color:"#0A84FF", fontWeight:"700", marginBottom:"4px" }}>#️⃣ Top Hashtags (สังเคราะห์จากทุกคลิป)</div>
              <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.7)", lineHeight:"1.8" }}>{synthesis.topHashtags}</div>
            </div>
            <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId==="syn-hash" ? "✅" : "📋"}</span>
          </div>

          {/* Avoid list */}
          {synthesis.avoidList?.length > 0 && (
            <div style={{ background:"rgba(255,59,92,0.07)", border:"1px solid rgba(255,59,92,0.2)", borderRadius:"10px", padding:"10px 12px", marginBottom:"10px" }}>
              <div style={{ fontSize:"11px", color:"#FF3B5C", fontWeight:"700", marginBottom:"6px" }}>🚫 สิ่งที่ควรหลีกเลี่ยง</div>
              {synthesis.avoidList.map((a, i) => <div key={i} style={{ fontSize:"12px", color:"rgba(255,255,255,0.7)", marginBottom:"3px" }}>· {a}</div>)}
            </div>
          )}

          {/* Next step */}
          <div style={{ background:"linear-gradient(135deg,rgba(255,204,0,0.1),rgba(255,107,53,0.1))", border:"1px solid rgba(255,204,0,0.25)", borderRadius:"12px", padding:"12px 14px" }}>
            <div style={{ fontSize:"11px", color:"#FFCC00", fontWeight:"700", marginBottom:"5px" }}>🚀 คำแนะนำสำคัญที่สุดสำหรับคลิปถัดไป</div>
            <div style={{ fontSize:"13px", color:"rgba(255,255,255,0.85)", lineHeight:"1.8", fontWeight:"600" }}>{synthesis.nextStepRecommendation}</div>
          </div>
        </div>
      )}
    </div>
  );
}


// ═══════════════════════════════════════════════
//  AI INTELLIGENCE ENGINE — Full autonomous analysis
// ═══════════════════════════════════════════════

function AIIntelligenceTab() {
  const [mode, setMode] = useState("dashboard"); // dashboard | input | result
  const [inputData, setInputData] = useState({
    productName: "",
    productCategory: "",
    priceRange: "",
    weekData: [
      { day:"จันทร์", views:"", clicks:"", orders:"", postTime:"", hookType:"", ctaType:"" },
      { day:"อังคาร", views:"", clicks:"", orders:"", postTime:"", hookType:"", ctaType:"" },
      { day:"พุธ",    views:"", clicks:"", orders:"", postTime:"", hookType:"", ctaType:"" },
      { day:"พฤหัส", views:"", clicks:"", orders:"", postTime:"", hookType:"", ctaType:"" },
      { day:"ศุกร์",  views:"", clicks:"", orders:"", postTime:"", hookType:"", ctaType:"" },
      { day:"เสาร์",  views:"", clicks:"", orders:"", postTime:"", hookType:"", ctaType:"" },
      { day:"อาทิตย์",views:"", clicks:"", orders:"", postTime:"", hookType:"", ctaType:"" },
    ]
  });
  const [analyzing, setAnalyzing] = useState(false);
  const [loadMsg, setLoadMsg] = useState("");
  const [result, setResult] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  const LOAD_MSGS = [
    "🔍 วิเคราะห์ประเภทสินค้า...",
    "📊 เลือก KPI ที่เหมาะกับสินค้านี้...",
    "🏆 จัดอันดับ KPI ตามผลกระทบ...",
    "🎣 หา Hook ที่ดีที่สุดจากข้อมูล...",
    "🛒 วิเคราะห์ CTA ที่ Conversion สูงสุด...",
    "⏰ หาเวลาโพสต์ที่เหมาะกับ Audience...",
    "🧠 สรุป Weekly Insight ครบชุด...",
  ];

  const copyText = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const hasEnoughData = inputData.productName && inputData.productCategory &&
    inputData.weekData.filter(d => d.views).length >= 3;

  const updateDay = (i, field, val) => {
    setInputData(prev => {
      const wd = [...prev.weekData];
      wd[i] = { ...wd[i], [field]: val };
      return { ...prev, weekData: wd };
    });
  };

  const runAnalysis = async () => {
    setAnalyzing(true);
    setResult(null);
    setMode("result");

    let msgIdx = 0;
    setLoadMsg(LOAD_MSGS[0]);
    const interval = setInterval(() => {
      msgIdx = (msgIdx + 1) % LOAD_MSGS.length;
      setLoadMsg(LOAD_MSGS[msgIdx]);
    }, 1600);

    const filledDays = inputData.weekData.filter(d => d.views);
    const dataStr = filledDays.map(d =>
      `${d.day}: views=${d.views||"-"} clicks=${d.clicks||"-"} orders=${d.orders||"-"} เวลาโพสต์=${d.postTime||"-"} hook=${d.hookType||"-"} cta=${d.ctaType||"-"}`
    ).join("\n");

    const prompt = `คุณคือ AI วิเคราะห์ TikTok Shop ที่เชี่ยวชาญตลาดไทย

ข้อมูลสินค้า:
ชื่อ: ${inputData.productName}
หมวดหมู่: ${inputData.productCategory}
ราคา: ${inputData.priceRange || "ไม่ระบุ"}

ข้อมูล Performance รายวัน (สัปดาห์นี้):
${dataStr}

วิเคราะห์แบบ AI ผู้เชี่ยวชาญ และตอบ JSON เท่านั้น:
{
  "productAnalysis": {
    "productType": "ประเภทสินค้าที่วิเคราะห์ได้ เช่น Impulse Buy / Considered Purchase / Daily Essential",
    "buyerPersona": "กลุ่มเป้าหมายที่เหมาะสมที่สุด",
    "contentStrategy": "กลยุทธ์คอนเทนต์ที่เหมาะกับสินค้านี้",
    "competitiveAdvantage": "จุดขายที่ควรเน้นใน TikTok"
  },
  "kpiSelection": {
    "primaryKPI": "KPI หลักที่สำคัญที่สุดสำหรับสินค้านี้ พร้อมอธิบายว่าทำไม",
    "secondaryKPIs": [
      {"name": "ชื่อ KPI", "reason": "ทำไมถึงสำคัญ", "target": "ค่าเป้าหมายแนะนำ"},
      {"name": "ชื่อ KPI", "reason": "ทำไมถึงสำคัญ", "target": "ค่าเป้าหมายแนะนำ"},
      {"name": "ชื่อ KPI", "reason": "ทำไมถึงสำคัญ", "target": "ค่าเป้าหมายแนะนำ"}
    ],
    "kpiRanking": ["KPI อันดับ 1", "KPI อันดับ 2", "KPI อันดับ 3", "KPI อันดับ 4"],
    "rankingReason": "เหตุผลที่จัดอันดับแบบนี้"
  },
  "hookAnalysis": {
    "bestHook": "Hook Type ที่ดีที่สุดสำหรับสินค้าและข้อมูลนี้",
    "hookScript": "ตัวอย่าง Hook Script ที่ดีที่สุด",
    "hookReason": "เหตุผลที่เลือก Hook นี้จากข้อมูล",
    "hookRanking": [
      {"type": "Pain Hook", "score": 85, "reason": "..."},
      {"type": "Result Hook", "score": 72, "reason": "..."},
      {"type": "Secret Hook", "score": 68, "reason": "..."}
    ]
  },
  "ctaAnalysis": {
    "bestCTA": "CTA Type ที่ดีที่สุดสำหรับสินค้านี้",
    "ctaScript": "ตัวอย่าง CTA Script ที่ดีที่สุด",
    "ctaReason": "เหตุผลที่เลือก CTA นี้",
    "ctaRanking": [
      {"type": "Flash Sale", "conversionPotential": "High/Med/Low", "reason": "..."},
      {"type": "Social Proof", "conversionPotential": "High/Med/Low", "reason": "..."},
      {"type": "Scarcity", "conversionPotential": "High/Med/Low", "reason": "..."},
      {"type": "Bundle Bait", "conversionPotential": "High/Med/Low", "reason": "..."}
    ]
  },
  "postingTimeAnalysis": {
    "bestTime": "เวลาที่ดีที่สุด เช่น 19:00-21:00",
    "bestDays": ["วัน 1", "วัน 2"],
    "worstTime": "เวลาที่ควรหลีกเลี่ยง",
    "timeReason": "เหตุผลจากข้อมูลและพฤติกรรม Audience สินค้านี้",
    "schedule": [
      {"slot": "เช้า 07:00-09:00", "score": 60, "note": "..."},
      {"slot": "กลางวัน 11:00-13:00", "score": 45, "note": "..."},
      {"slot": "เย็น 17:00-19:00", "score": 78, "note": "..."},
      {"slot": "ไพรม์ไทม์ 19:00-22:00", "score": 92, "note": "..."},
      {"slot": "ดึก 22:00-00:00", "score": 55, "note": "..."}
    ]
  },
  "weeklyInsight": {
    "overallScore": 75,
    "trend": "UP / DOWN / STABLE",
    "trendNote": "สรุปทิศทาง",
    "topWin": "สิ่งที่ทำได้ดีที่สุดสัปดาห์นี้",
    "topProblem": "ปัญหาหลักที่ต้องแก้",
    "actionItems": [
      {"priority": "HIGH", "action": "สิ่งที่ต้องทำทันที", "impact": "ผลที่คาดว่าจะเกิด"},
      {"priority": "MED", "action": "สิ่งที่ควรทำภายใน 3 วัน", "impact": "ผลที่คาดว่าจะเกิด"},
      {"priority": "LOW", "action": "สิ่งที่วางแผนระยะยาว", "impact": "ผลที่คาดว่าจะเกิด"}
    ],
    "nextWeekStrategy": "กลยุทธ์สัปดาห์หน้าที่แนะนำ",
    "contentCalendar": [
      {"day": "จันทร์", "contentType": "...", "hook": "...", "bestTime": "..."},
      {"day": "พุธ", "contentType": "...", "hook": "...", "bestTime": "..."},
      {"day": "ศุกร์", "contentType": "...", "hook": "...", "bestTime": "..."},
      {"day": "อาทิตย์", "contentType": "...", "hook": "...", "bestTime": "..."}
    ]
  }
}`;

    try {
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: "คุณคือ AI วิเคราะห์ TikTok Shop ผู้เชี่ยวชาญตลาดไทย ตอบ JSON เท่านั้น ห้ามมีข้อความอื่น",
          messages: [{ role: "user", content: prompt }]
        })
      });
      const data = await resp.json();
      const raw = data.content?.map(i => i.text || "").join("") || "";
      const clean = raw.replace(/```json|```/g, "").trim();
      setResult(JSON.parse(clean));
    } catch (e) {
      setResult({ error: "วิเคราะห์ไม่ได้ กรุณาลองใหม่" });
    }
    clearInterval(interval);
    setAnalyzing(false);
  };

  const inputStyle = {
    background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: "8px", padding: "8px 10px", color: "#F0F0F0",
    fontSize: "13px", outline: "none", width: "100%", boxSizing: "border-box"
  };

  const priorityColor = { HIGH: "#FF3B5C", MED: "#FF6B35", LOW: "#0A84FF" };
  const convColor = { High: "#30D158", Med: "#FF6B35", Low: "rgba(255,255,255,0.4)" };

  // ── RESULT ──
  if (mode === "result") return (
    <div>
      <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"16px" }}>
        <button onClick={() => { setMode("dashboard"); setResult(null); }}
          style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#F0F0F0", borderRadius:"8px", padding:"6px 12px", cursor:"pointer", fontSize:"13px" }}>← กลับ</button>
        <div style={{ fontWeight:"700", fontSize:"16px" }}>AI Insight Report</div>
        {result && !analyzing && <div style={{ marginLeft:"auto", background:"rgba(48,209,88,0.15)", color:"#30D158", fontSize:"11px", padding:"3px 10px", borderRadius:"20px", fontWeight:"700" }}>✓ วิเคราะห์แล้ว</div>}
      </div>

      {analyzing && (
        <div style={{ textAlign:"center", padding:"50px 20px" }}>
          <div style={{ fontSize:"40px", marginBottom:"14px", display:"inline-block", animation:"spin 1.2s linear infinite" }}>🧠</div>
          <div style={{ color:"rgba(255,255,255,0.8)", fontSize:"14px", fontWeight:"600", marginBottom:"6px" }}>{loadMsg}</div>
          <div style={{ color:"rgba(255,255,255,0.35)", fontSize:"12px" }}>AI กำลังวิเคราะห์ข้อมูลเชิงลึก...</div>
          <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
        </div>
      )}

      {result?.error && (
        <div style={{ background:"rgba(255,59,92,0.1)", border:"1px solid rgba(255,59,92,0.3)", borderRadius:"12px", padding:"16px", textAlign:"center", color:"#FF3B5C" }}>{result.error}</div>
      )}

      {result && !result.error && !analyzing && (() => {
        const pa = result.productAnalysis;
        const kpi = result.kpiSelection;
        const ha = result.hookAnalysis;
        const ca = result.ctaAnalysis;
        const ta = result.postingTimeAnalysis;
        const wi = result.weeklyInsight;
        return (
          <div>
            {/* Overall score */}
            <div style={{ background:"linear-gradient(135deg,rgba(255,59,92,0.15),rgba(123,47,190,0.15))", border:"1px solid rgba(255,59,92,0.25)", borderRadius:"16px", padding:"16px", marginBottom:"14px", display:"flex", gap:"14px", alignItems:"center" }}>
              <div style={{ textAlign:"center", flexShrink:0 }}>
                <div style={{ fontSize:"36px", fontWeight:"900", background:"linear-gradient(135deg,#FF3B5C,#7B2FBE)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>{wi?.overallScore}</div>
                <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.4)", marginTop:"-2px" }}>คะแนน</div>
              </div>
              <div>
                <div style={{ fontWeight:"700", fontSize:"14px" }}>{inputData.productName}</div>
                <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.5)", marginBottom:"4px" }}>{pa?.productType}</div>
                <div style={{ display:"flex", gap:"6px", flexWrap:"wrap" }}>
                  <span style={{ background: wi?.trend==="UP" ? "rgba(48,209,88,0.2)" : wi?.trend==="DOWN" ? "rgba(255,59,92,0.2)" : "rgba(255,204,0,0.2)", color: wi?.trend==="UP" ? "#30D158" : wi?.trend==="DOWN" ? "#FF3B5C" : "#FFCC00", fontSize:"11px", padding:"2px 8px", borderRadius:"20px", fontWeight:"700" }}>
                    {wi?.trend==="UP" ? "📈 ขาขึ้น" : wi?.trend==="DOWN" ? "📉 ขาลง" : "➡️ ทรงตัว"}
                  </span>
                  <span style={{ background:"rgba(255,255,255,0.08)", fontSize:"11px", padding:"2px 8px", borderRadius:"20px", color:"rgba(255,255,255,0.6)" }}>{wi?.trendNote}</span>
                </div>
              </div>
            </div>

            {/* Product Analysis */}
            <AICard title="🛍️ วิเคราะห์สินค้า" color="#FF6B35">
              <InfoRow label="ประเภท" val={pa?.productType} color="#FF6B35" />
              <InfoRow label="Persona" val={pa?.buyerPersona} />
              <InfoRow label="กลยุทธ์" val={pa?.contentStrategy} />
              <InfoRow label="จุดขายหลัก" val={pa?.competitiveAdvantage} color="#FF3B5C" />
            </AICard>

            {/* KPI Selection + Ranking */}
            <AICard title="📊 KPI ที่ AI เลือก + จัดอันดับ" color="#0A84FF">
              <div style={{ background:"rgba(10,132,255,0.1)", border:"1px solid rgba(10,132,255,0.3)", borderRadius:"10px", padding:"10px 12px", marginBottom:"10px" }}>
                <div style={{ fontSize:"10px", color:"#0A84FF", fontWeight:"700", marginBottom:"4px", letterSpacing:"1px" }}>PRIMARY KPI</div>
                <div style={{ fontSize:"13px", lineHeight:"1.7" }}>{kpi?.primaryKPI}</div>
              </div>
              {kpi?.secondaryKPIs?.map((k, i) => (
                <div key={i} style={{ display:"flex", gap:"10px", marginBottom:"8px", alignItems:"flex-start" }}>
                  <div style={{ background:"#0A84FF", color:"#fff", width:"20px", height:"20px", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"10px", fontWeight:"700", flexShrink:0, marginTop:"2px" }}>{i+2}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:"12px", fontWeight:"700", color:"#0A84FF" }}>{k.name}</div>
                    <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.6)" }}>{k.reason}</div>
                    <div style={{ fontSize:"11px", color:"#30D158", marginTop:"2px" }}>🎯 เป้าหมาย: {k.target}</div>
                  </div>
                </div>
              ))}
              <div style={{ marginTop:"8px", background:"rgba(255,255,255,0.04)", borderRadius:"8px", padding:"8px 10px" }}>
                <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"4px" }}>เหตุผลการจัดอันดับ</div>
                <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.75)", lineHeight:"1.7" }}>{kpi?.rankingReason}</div>
              </div>
            </AICard>

            {/* Hook Analysis */}
            <AICard title="🎣 Hook ที่ดีที่สุด" color="#FF3B5C">
              <div style={{ background:"rgba(255,59,92,0.1)", border:"1px solid rgba(255,59,92,0.3)", borderRadius:"10px", padding:"10px 12px", marginBottom:"10px" }}>
                <div style={{ fontSize:"10px", color:"#FF3B5C", fontWeight:"700", marginBottom:"4px" }}>BEST HOOK — {ha?.bestHook}</div>
                <div
                  onClick={() => copyText(ha?.hookScript, "best-hook")}
                  style={{ fontSize:"13px", lineHeight:"1.7", cursor:"pointer", display:"flex", justifyContent:"space-between", gap:"8px" }}
                >
                  <span>"{ha?.hookScript}"</span>
                  <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId==="best-hook" ? "✅" : "📋"}</span>
                </div>
              </div>
              <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.6)", marginBottom:"10px", lineHeight:"1.7" }}>💡 {ha?.hookReason}</div>
              {ha?.hookRanking?.map((h, i) => (
                <div key={i} style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"7px" }}>
                  <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.5)", width:"80px", flexShrink:0 }}>{h.type}</div>
                  <div style={{ flex:1, height:"8px", background:"rgba(255,255,255,0.08)", borderRadius:"4px", overflow:"hidden" }}>
                    <div style={{ height:"100%", width:`${h.score}%`, background: i===0 ? "#FF3B5C" : i===1 ? "#FF6B35" : "#7B2FBE", borderRadius:"4px", transition:"width 1s" }} />
                  </div>
                  <div style={{ fontSize:"11px", fontWeight:"700", color: i===0 ? "#FF3B5C" : "#FF6B35", width:"28px", textAlign:"right" }}>{h.score}</div>
                </div>
              ))}
            </AICard>

            {/* CTA Analysis */}
            <AICard title="🛒 CTA ที่ดีที่สุด" color="#7B2FBE">
              <div style={{ background:"rgba(123,47,190,0.1)", border:"1px solid rgba(123,47,190,0.3)", borderRadius:"10px", padding:"10px 12px", marginBottom:"10px" }}>
                <div style={{ fontSize:"10px", color:"#A855F7", fontWeight:"700", marginBottom:"4px" }}>BEST CTA — {ca?.bestCTA}</div>
                <div
                  onClick={() => copyText(ca?.ctaScript, "best-cta")}
                  style={{ fontSize:"13px", lineHeight:"1.7", cursor:"pointer", display:"flex", justifyContent:"space-between", gap:"8px" }}
                >
                  <span>"{ca?.ctaScript}"</span>
                  <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId==="best-cta" ? "✅" : "📋"}</span>
                </div>
              </div>
              <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.6)", marginBottom:"10px" }}>💡 {ca?.ctaReason}</div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"6px" }}>
                {ca?.ctaRanking?.map((c, i) => (
                  <div key={i} style={{ background:"rgba(255,255,255,0.04)", borderRadius:"8px", padding:"8px 10px", border:"1px solid rgba(255,255,255,0.07)" }}>
                    <div style={{ fontSize:"11px", fontWeight:"700", marginBottom:"3px" }}>{c.type}</div>
                    <div style={{ display:"inline-block", background: convColor[c.conversionPotential]+"22", color: convColor[c.conversionPotential], fontSize:"10px", padding:"1px 7px", borderRadius:"20px", fontWeight:"700", marginBottom:"4px" }}>{c.conversionPotential}</div>
                    <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.45)", lineHeight:"1.5" }}>{c.reason}</div>
                  </div>
                ))}
              </div>
            </AICard>

            {/* Posting Time */}
            <AICard title="⏰ เวลาโพสต์ที่ดีที่สุด" color="#30D158">
              <div style={{ display:"flex", gap:"8px", marginBottom:"10px", flexWrap:"wrap" }}>
                <div style={{ background:"rgba(48,209,88,0.15)", border:"1px solid rgba(48,209,88,0.3)", borderRadius:"10px", padding:"8px 12px", flex:1, textAlign:"center" }}>
                  <div style={{ fontSize:"10px", color:"#30D158", fontWeight:"700", marginBottom:"2px" }}>BEST TIME</div>
                  <div style={{ fontSize:"14px", fontWeight:"800" }}>{ta?.bestTime}</div>
                </div>
                <div style={{ background:"rgba(255,59,92,0.1)", border:"1px solid rgba(255,59,92,0.2)", borderRadius:"10px", padding:"8px 12px", flex:1, textAlign:"center" }}>
                  <div style={{ fontSize:"10px", color:"#FF3B5C", fontWeight:"700", marginBottom:"2px" }}>AVOID</div>
                  <div style={{ fontSize:"13px", fontWeight:"700" }}>{ta?.worstTime}</div>
                </div>
              </div>
              <div style={{ display:"flex", gap:"6px", marginBottom:"10px", flexWrap:"wrap" }}>
                {ta?.bestDays?.map((d, i) => (
                  <span key={i} style={{ background:"rgba(48,209,88,0.2)", color:"#30D158", fontSize:"12px", padding:"3px 10px", borderRadius:"20px", fontWeight:"700" }}>📅 {d}</span>
                ))}
              </div>
              <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.55)", marginBottom:"10px", lineHeight:"1.7" }}>💡 {ta?.timeReason}</div>
              {ta?.schedule?.map((s, i) => (
                <div key={i} style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"6px" }}>
                  <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.5)", width:"110px", flexShrink:0 }}>{s.slot}</div>
                  <div style={{ flex:1, height:"8px", background:"rgba(255,255,255,0.08)", borderRadius:"4px", overflow:"hidden" }}>
                    <div style={{ height:"100%", width:`${s.score}%`, background: s.score >= 85 ? "#30D158" : s.score >= 65 ? "#FF6B35" : "rgba(255,255,255,0.2)", borderRadius:"4px" }} />
                  </div>
                  <div style={{ fontSize:"11px", fontWeight:"700", color: s.score >= 85 ? "#30D158" : s.score >= 65 ? "#FF6B35" : "rgba(255,255,255,0.4)", width:"26px", textAlign:"right" }}>{s.score}</div>
                </div>
              ))}
            </AICard>

            {/* Weekly Insight */}
            <AICard title="🧠 Weekly Insight + Action Plan" color="#FFCC00">
              <div style={{ background:"rgba(255,204,0,0.08)", borderRadius:"10px", padding:"10px 12px", marginBottom:"10px" }}>
                <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.7)", marginBottom:"6px" }}>
                  <span style={{ color:"#30D158", fontWeight:"700" }}>✅ Win: </span>{wi?.topWin}
                </div>
                <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.7)" }}>
                  <span style={{ color:"#FF3B5C", fontWeight:"700" }}>⚠️ ปัญหา: </span>{wi?.topProblem}
                </div>
              </div>

              <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"8px", letterSpacing:"1px" }}>ACTION ITEMS</div>
              {wi?.actionItems?.map((a, i) => (
                <div key={i} style={{ display:"flex", gap:"10px", marginBottom:"8px", background:"rgba(255,255,255,0.03)", borderRadius:"10px", padding:"10px 12px", border:`1px solid ${priorityColor[a.priority]}22` }}>
                  <div style={{ background: priorityColor[a.priority], color:"#fff", fontSize:"9px", fontWeight:"800", padding:"2px 7px", borderRadius:"20px", flexShrink:0, alignSelf:"flex-start", marginTop:"2px" }}>{a.priority}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:"12px", fontWeight:"700", marginBottom:"3px" }}>{a.action}</div>
                    <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.5)" }}>📈 {a.impact}</div>
                  </div>
                </div>
              ))}

              <div style={{ marginTop:"10px", background:"rgba(255,204,0,0.06)", border:"1px solid rgba(255,204,0,0.2)", borderRadius:"10px", padding:"10px 12px", marginBottom:"12px" }}>
                <div style={{ fontSize:"11px", color:"#FFCC00", fontWeight:"700", marginBottom:"4px" }}>🗓️ กลยุทธ์สัปดาห์หน้า</div>
                <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.75)", lineHeight:"1.7" }}>{wi?.nextWeekStrategy}</div>
              </div>

              <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"8px", letterSpacing:"1px" }}>CONTENT CALENDAR สัปดาห์หน้า</div>
              {wi?.contentCalendar?.map((c, i) => (
                <div key={i} style={{ display:"flex", gap:"10px", marginBottom:"7px", alignItems:"flex-start" }}>
                  <div style={{ background:"rgba(255,204,0,0.15)", color:"#FFCC00", fontSize:"11px", fontWeight:"700", padding:"3px 8px", borderRadius:"8px", flexShrink:0, minWidth:"50px", textAlign:"center" }}>{c.day}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:"12px", fontWeight:"600" }}>{c.contentType}</div>
                    <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.45)" }}>Hook: {c.hook} · {c.bestTime}</div>
                  </div>
                </div>
              ))}
            </AICard>
          </div>
        );
      })()}
    </div>
  );

  // ── INPUT FORM ──
  if (mode === "input") return (
    <div>
      <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"16px" }}>
        <button onClick={() => setMode("dashboard")} style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#F0F0F0", borderRadius:"8px", padding:"6px 12px", cursor:"pointer", fontSize:"13px" }}>← กลับ</button>
        <div style={{ fontWeight:"700", fontSize:"16px" }}>ป้อนข้อมูล Performance</div>
      </div>

      {/* Product info */}
      <div style={{ background:"rgba(255,255,255,0.03)", borderRadius:"14px", padding:"14px", marginBottom:"14px", border:"1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"10px", letterSpacing:"1px" }}>ข้อมูลสินค้า</div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"8px", marginBottom:"8px" }}>
          <div>
            <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.4)", marginBottom:"4px" }}>ชื่อสินค้า *</div>
            <input style={inputStyle} placeholder="เช่น MizuMi Cream" value={inputData.productName} onChange={e => setInputData(p => ({...p, productName:e.target.value}))} />
          </div>
          <div>
            <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.4)", marginBottom:"4px" }}>หมวดหมู่ *</div>
            <select style={{...inputStyle, cursor:"pointer"}} value={inputData.productCategory} onChange={e => setInputData(p => ({...p, productCategory:e.target.value}))}>
              <option value="">เลือก...</option>
              <option>Skincare</option><option>Makeup</option><option>Haircare</option>
              <option>Supplement</option><option>Fashion</option><option>Food</option><option>Other</option>
            </select>
          </div>
        </div>
        <div>
          <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.4)", marginBottom:"4px" }}>ราคา</div>
          <input style={inputStyle} placeholder="เช่น 299" value={inputData.priceRange} onChange={e => setInputData(p => ({...p, priceRange:e.target.value}))} />
        </div>
      </div>

      {/* Weekly data table */}
      <div style={{ background:"rgba(255,255,255,0.03)", borderRadius:"14px", padding:"14px", border:"1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"4px", letterSpacing:"1px" }}>ข้อมูล Performance รายวัน</div>
        <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.25)", marginBottom:"12px" }}>กรอกอย่างน้อย 3 วัน — ยิ่งครบยิ่งแม่น</div>
        {inputData.weekData.map((day, i) => (
          <div key={i} style={{ marginBottom:"10px", background:"rgba(255,255,255,0.03)", borderRadius:"10px", padding:"10px" }}>
            <div style={{ fontSize:"12px", fontWeight:"700", color:"rgba(255,255,255,0.8)", marginBottom:"8px" }}>{day.day}</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"6px", marginBottom:"6px" }}>
              <div>
                <div style={{ fontSize:"9px", color:"rgba(255,255,255,0.35)", marginBottom:"3px" }}>👁️ Views</div>
                <input style={{...inputStyle, fontSize:"12px", padding:"6px 8px"}} placeholder="0" type="number" value={day.views} onChange={e => updateDay(i,"views",e.target.value)} />
              </div>
              <div>
                <div style={{ fontSize:"9px", color:"rgba(255,255,255,0.35)", marginBottom:"3px" }}>👆 Clicks</div>
                <input style={{...inputStyle, fontSize:"12px", padding:"6px 8px"}} placeholder="0" type="number" value={day.clicks} onChange={e => updateDay(i,"clicks",e.target.value)} />
              </div>
              <div>
                <div style={{ fontSize:"9px", color:"rgba(255,255,255,0.35)", marginBottom:"3px" }}>🛒 Orders</div>
                <input style={{...inputStyle, fontSize:"12px", padding:"6px 8px"}} placeholder="0" type="number" value={day.orders} onChange={e => updateDay(i,"orders",e.target.value)} />
              </div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"6px" }}>
              <div>
                <div style={{ fontSize:"9px", color:"rgba(255,255,255,0.35)", marginBottom:"3px" }}>⏰ เวลาโพสต์</div>
                <input style={{...inputStyle, fontSize:"12px", padding:"6px 8px"}} placeholder="19:00" value={day.postTime} onChange={e => updateDay(i,"postTime",e.target.value)} />
              </div>
              <div>
                <div style={{ fontSize:"9px", color:"rgba(255,255,255,0.35)", marginBottom:"3px" }}>🎣 Hook ที่ใช้</div>
                <select style={{...inputStyle, fontSize:"11px", padding:"6px 8px", cursor:"pointer"}} value={day.hookType} onChange={e => updateDay(i,"hookType",e.target.value)}>
                  <option value="">-</option>
                  <option>Pain</option><option>Result</option><option>Secret</option>
                </select>
              </div>
              <div>
                <div style={{ fontSize:"9px", color:"rgba(255,255,255,0.35)", marginBottom:"3px" }}>🛒 CTA ที่ใช้</div>
                <select style={{...inputStyle, fontSize:"11px", padding:"6px 8px", cursor:"pointer"}} value={day.ctaType} onChange={e => updateDay(i,"ctaType",e.target.value)}>
                  <option value="">-</option>
                  <option>Flash Sale</option><option>Scarcity</option><option>Bundle</option><option>Social Proof</option>
                </select>
              </div>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={runAnalysis}
        disabled={!hasEnoughData}
        style={{ width:"100%", padding:"14px", borderRadius:"12px", border:"none", marginTop:"14px", cursor: hasEnoughData ? "pointer" : "not-allowed", background: hasEnoughData ? "linear-gradient(90deg,#FF3B5C,#7B2FBE)" : "rgba(255,255,255,0.08)", color: hasEnoughData ? "#fff" : "rgba(255,255,255,0.3)", fontWeight:"700", fontSize:"15px" }}
      >
        {hasEnoughData ? "🧠 วิเคราะห์ด้วย AI" : `กรอกข้อมูลอีก ${3 - inputData.weekData.filter(d=>d.views).length} วัน`}
      </button>
    </div>
  );

  // ── DASHBOARD ──
  return (
    <div>
      <div style={{ textAlign:"center", padding:"10px 0 16px" }}>
        <div style={{ fontSize:"40px", marginBottom:"8px" }}>🧠</div>
        <div style={{ fontWeight:"800", fontSize:"18px", background:"linear-gradient(90deg,#FF3B5C,#7B2FBE)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>AI Intelligence Engine</div>
        <div style={{ fontSize:"13px", color:"rgba(255,255,255,0.45)", marginTop:"4px" }}>วิเคราะห์ครบจบ ไม่ต้องเดาเอง</div>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"8px", marginBottom:"16px" }}>
        {[
          { icon:"🛍️", title:"วิเคราะห์สินค้า", desc:"ประเภท / Persona / กลยุทธ์", color:"#FF6B35" },
          { icon:"📊", title:"เลือก & จัดอันดับ KPI", desc:"KPI ที่เหมาะกับสินค้านี้", color:"#0A84FF" },
          { icon:"🎣", title:"Hook ที่ดีที่สุด", desc:"Score + เหตุผล + Script", color:"#FF3B5C" },
          { icon:"🛒", title:"CTA ที่ดีที่สุด", desc:"Conversion ranking", color:"#7B2FBE" },
          { icon:"⏰", title:"เวลาโพสต์ที่เหมาะ", desc:"Best slot จากข้อมูลจริง", color:"#30D158" },
          { icon:"🗓️", title:"Weekly Insight", desc:"Action plan + Calendar", color:"#FFCC00" },
        ].map((item, i) => (
          <div key={i} style={{ background:"rgba(255,255,255,0.04)", border:`1px solid ${item.color}22`, borderRadius:"12px", padding:"12px 10px", textAlign:"center" }}>
            <div style={{ fontSize:"24px", marginBottom:"5px" }}>{item.icon}</div>
            <div style={{ fontSize:"12px", fontWeight:"700", color:item.color, marginBottom:"2px" }}>{item.title}</div>
            <div style={{ fontSize:"10px", color:"rgba(255,255,255,0.35)" }}>{item.desc}</div>
          </div>
        ))}
      </div>

      <button
        onClick={() => setMode("input")}
        style={{ width:"100%", padding:"16px", borderRadius:"14px", border:"none", cursor:"pointer", background:"linear-gradient(90deg,#FF3B5C,#FF6B35,#7B2FBE)", color:"#fff", fontWeight:"800", fontSize:"16px", boxShadow:"0 4px 20px rgba(255,59,92,0.4)" }}
      >
        🧠 เริ่มวิเคราะห์ด้วย AI
      </button>
      <div style={{ textAlign:"center", fontSize:"11px", color:"rgba(255,255,255,0.25)", marginTop:"8px" }}>ป้อนข้อมูล Performance รายวัน → AI วิเคราะห์ให้ครบ 7 หัวข้อ</div>
    </div>
  );
}

// ── Reusable small components for AI tab ──
function AICard({ title, color, children }) {
  return (
    <div style={{ background:"rgba(255,255,255,0.03)", border:`1px solid ${color}33`, borderRadius:"14px", padding:"14px", marginBottom:"12px" }}>
      <div style={{ fontWeight:"700", fontSize:"13px", color, marginBottom:"10px" }}>{title}</div>
      {children}
    </div>
  );
}

function InfoRow({ label, val, color }) {
  if (!val) return null;
  return (
    <div style={{ display:"flex", gap:"8px", marginBottom:"6px", alignItems:"flex-start" }}>
      <span style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", flexShrink:0, minWidth:"60px" }}>{label}</span>
      <span style={{ fontSize:"12px", color: color || "rgba(255,255,255,0.8)", flex:1, lineHeight:"1.6" }}>{val}</span>
    </div>
  );
}

// ───────── Main App ─────────
export default function TikTokContentSystem() {
  const [activeTab, setActiveTab] = useState("products");
  const [selectedHook, setSelectedHook] = useState(null);
  const [selectedContent, setSelectedContent] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  const copyText = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const tabs = [
    { id:"products", label:"📦 สินค้า" },
    { id:"ai",       label:"🧠 AI Insights" },
    { id:"hooks",    label:"🎣 Hook 3 วิ" },
    { id:"content",  label:"🎬 แนวเนื้อหา" },
    { id:"cta",      label:"🛒 CTA" },
    { id:"repurchase",label:"🔄 ซื้อซ้ำ" },
    { id:"hashtags", label:"#️⃣ Hashtag" },
  ];

  return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(135deg,#0D0D1A 0%,#1A0A2E 50%,#0D1A2E 100%)", fontFamily:"'Segoe UI','Noto Sans Thai',sans-serif", color:"#F0F0F0" }}>
      <div style={{ background:"linear-gradient(90deg,#FF3B5C,#FF6B35,#7B2FBE)", padding:"16px 20px 12px", position:"sticky", top:0, zIndex:100, boxShadow:"0 4px 20px rgba(255,59,92,0.4)" }}>
        <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.7)", letterSpacing:"2px", textTransform:"uppercase" }}>TikTok Shop</div>
        <div style={{ fontSize:"20px", fontWeight:"800", letterSpacing:"-0.5px" }}>ระบบบริหารคอนเทนต์</div>
        <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.8)", marginTop:"2px" }}>สินค้า · Hook · Script · CTA · Hashtag · ซื้อซ้ำ</div>
      </div>

      <div style={{ display:"flex", background:"#0D0D1A", borderBottom:"1px solid rgba(255,255,255,0.08)", overflowX:"auto", position:"sticky", top:"70px", zIndex:99 }}>
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ flex:"0 0 auto", padding:"11px 14px", background:"none", border:"none", color: activeTab===tab.id ? "#FF3B5C" : "rgba(255,255,255,0.45)", borderBottom: activeTab===tab.id ? "2px solid #FF3B5C" : "2px solid transparent", cursor:"pointer", fontSize:"12px", fontWeight: activeTab===tab.id ? "700" : "400", whiteSpace:"nowrap" }}>
            {tab.label}
          </button>
        ))}
      </div>

      <div style={{ padding:"16px", maxWidth:"600px", margin:"0 auto" }}>
        {activeTab === "products" && <ProductTab />}

        {activeTab === "ai" && <AIIntelligenceTab />}

        {activeTab === "hooks" && (
          <div>
            <div style={{ background:"rgba(255,59,92,0.1)", border:"1px solid rgba(255,59,92,0.3)", borderRadius:"12px", padding:"12px 14px", marginBottom:"16px", fontSize:"13px", lineHeight:"1.7" }}>
              Hook 3 วิแรกต้องทำให้คน <strong style={{ color:"#FF3B5C" }}>หยุดนิ้ว</strong> ก่อนสมองจะตัดสินว่าจะดูต่อหรือเลื่อนผ่าน ใช้ <strong>ภาพ + ข้อความ + เสียง</strong> พร้อมกัน ไม่มีการ Intro ตัวเอง
            </div>
            {HOOKS.map(hook => (
              <div key={hook.id} onClick={() => setSelectedHook(selectedHook?.id===hook.id ? null : hook)} style={{ background: selectedHook?.id===hook.id ? `linear-gradient(135deg,${hook.color}22,${hook.color}11)` : "rgba(255,255,255,0.04)", border:`1px solid ${selectedHook?.id===hook.id ? hook.color : "rgba(255,255,255,0.08)"}`, borderRadius:"14px", padding:"16px", marginBottom:"10px", cursor:"pointer" }}>
                <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"6px" }}>
                  <span style={{ fontSize:"22px" }}>{hook.icon}</span>
                  <div>
                    <div style={{ fontWeight:"700", fontSize:"15px" }}>{hook.type}</div>
                    <div style={{ display:"inline-block", background:hook.color, color:"#fff", fontSize:"10px", padding:"2px 8px", borderRadius:"20px", fontWeight:"600" }}>{hook.label}</div>
                  </div>
                  <div style={{ marginLeft:"auto", color:"rgba(255,255,255,0.3)", fontSize:"12px" }}>{selectedHook?.id===hook.id ? "▲" : "▼"}</div>
                </div>
                <div style={{ background:"rgba(0,0,0,0.3)", borderRadius:"8px", padding:"8px 10px", fontSize:"11px", color:hook.color, fontFamily:"monospace", marginBottom:"4px" }}>📐 {hook.formula}</div>
                <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)" }}>🧠 {hook.stopTrigger}</div>
                {selectedHook?.id===hook.id && (
                  <div style={{ marginTop:"12px" }}>
                    <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.5)", marginBottom:"6px" }}>ตัวอย่าง Hook Scripts:</div>
                    {hook.examples.map((ex,i) => (
                      <div key={i} onClick={e => { e.stopPropagation(); copyText(ex,`h-${hook.id}-${i}`); }} style={{ background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:"10px", padding:"10px 12px", marginBottom:"6px", fontSize:"13px", lineHeight:"1.6", cursor:"pointer", display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:"8px" }}>
                        <span>"{ex}"</span>
                        <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId===`h-${hook.id}-${i}` ? "✅" : "📋"}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {activeTab === "content" && (
          <div>
            <div style={{ marginBottom:"12px", fontSize:"13px", color:"rgba(255,255,255,0.5)" }}>เลือกแนวคอนเทนต์เพื่อดู Script Structure + วิธีแทรกสินค้า</div>
            {CONTENT_TYPES.map(ct => (
              <div key={ct.id} style={{ background: selectedContent?.id===ct.id ? `linear-gradient(135deg,${ct.color}22,${ct.color}11)` : "rgba(255,255,255,0.04)", border:`1px solid ${selectedContent?.id===ct.id ? ct.color : "rgba(255,255,255,0.08)"}`, borderRadius:"14px", marginBottom:"10px", overflow:"hidden" }}>
                <div onClick={() => setSelectedContent(selectedContent?.id===ct.id ? null : ct)} style={{ padding:"16px", cursor:"pointer", display:"flex", alignItems:"center", gap:"12px" }}>
                  <span style={{ fontSize:"28px" }}>{ct.icon}</span>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:"700", fontSize:"15px" }}>{ct.name}</div>
                    <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.5)" }}>{ct.narrative}</div>
                  </div>
                  <div style={{ color:"rgba(255,255,255,0.3)", fontSize:"12px" }}>{selectedContent?.id===ct.id ? "▲" : "▼"}</div>
                </div>
                {selectedContent?.id===ct.id && (
                  <div style={{ padding:"0 16px 16px" }}>
                    <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"8px", letterSpacing:"1px" }}>SCRIPT STRUCTURE</div>
                    {ct.structure.map((s,i) => (
                      <div key={i} style={{ display:"flex", gap:"10px", marginBottom:"6px", alignItems:"flex-start" }}>
                        <div style={{ background:ct.color, color:"#fff", width:"22px", height:"22px", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"11px", fontWeight:"700", flexShrink:0, marginTop:"1px" }}>{s.step}</div>
                        <div><span style={{ color:ct.color, fontWeight:"600", fontSize:"12px" }}>{s.label}: </span><span style={{ fontSize:"12px", color:"rgba(255,255,255,0.75)" }}>{s.desc}</span></div>
                      </div>
                    ))}
                    <div style={{ fontSize:"11px", color:"rgba(255,255,255,0.4)", marginBottom:"6px", marginTop:"10px", letterSpacing:"1px" }}>PRODUCT INSERT SCRIPT</div>
                    <div onClick={() => copyText(ct.productInsertScript,`ct-${ct.id}`)} style={{ background:"rgba(0,0,0,0.4)", border:`1px solid ${ct.color}44`, borderRadius:"10px", padding:"12px", fontSize:"13px", lineHeight:"1.7", cursor:"pointer", display:"flex", justifyContent:"space-between", gap:"8px" }}>
                      <span>"{ct.productInsertScript}"</span>
                      <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId===`ct-${ct.id}` ? "✅" : "📋"}</span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {activeTab === "cta" && (
          <div>
            <div style={{ background:"rgba(255,59,92,0.1)", border:"1px solid rgba(255,59,92,0.3)", borderRadius:"12px", padding:"12px 14px", marginBottom:"16px", fontSize:"13px", lineHeight:"1.7" }}>
              🧠 <strong>หลักการ CTA แบบ Invisible:</strong> อย่าพูดว่า "ซื้อเลย" ตรง ๆ ให้พูดว่า <span style={{ color:"#FF3B5C" }}>"กดเก็บไว้ก่อน" / "ลองดูก่อนนะ" / "เดี๋ยวหมด"</span> แทน
            </div>
            {CTA_BANK.map((cta,i) => (
              <div key={i} style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"14px", padding:"14px", marginBottom:"10px" }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"8px" }}>
                  <div><span style={{ fontWeight:"700", fontSize:"14px" }}>{cta.label}</span><span style={{ marginLeft:"8px", background:"rgba(255,255,255,0.1)", fontSize:"10px", padding:"2px 8px", borderRadius:"20px", color:"rgba(255,255,255,0.6)" }}>{cta.type}</span></div>
                  <span style={{ background:"rgba(255,107,53,0.2)", color:"#FF6B35", fontSize:"10px", padding:"2px 8px", borderRadius:"20px", fontWeight:"600" }}>🧠 {cta.trigger}</span>
                </div>
                <div onClick={() => copyText(cta.text,`cta-${i}`)} style={{ background:"rgba(0,0,0,0.3)", borderRadius:"10px", padding:"10px 12px", fontSize:"13px", lineHeight:"1.7", cursor:"pointer", display:"flex", justifyContent:"space-between", gap:"8px", border:"1px solid rgba(255,255,255,0.06)" }}>
                  <span>"{cta.text}"</span>
                  <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId===`cta-${i}` ? "✅" : "📋"}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "repurchase" && (
          <div>
            <div style={{ background:"rgba(123,47,190,0.15)", border:"1px solid rgba(123,47,190,0.4)", borderRadius:"12px", padding:"12px 14px", marginBottom:"16px", fontSize:"13px", lineHeight:"1.8" }}>
              🔄 <strong>กลยุทธ์อัตราซื้อซ้ำ</strong><br />แทรก Repurchase Signal ใน <span style={{ color:"#7B2FBE" }}>ทุก 3 คอนเทนต์</span>
            </div>
            <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"14px", padding:"14px", marginBottom:"14px" }}>
              {[{label:"Routine Content",pct:40,color:"#7B2FBE"},{label:"Result Content",pct:30,color:"#FF3B5C"},{label:"Bundle/Upsell",pct:20,color:"#FF6B35"},{label:"Community",pct:10,color:"#0A84FF"}].map((item,i) => (
                <div key={i} style={{ marginBottom:"8px" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", fontSize:"12px", marginBottom:"4px" }}><span>{item.label}</span><span style={{ color:item.color, fontWeight:"700" }}>{item.pct}%</span></div>
                  <div style={{ height:"6px", background:"rgba(255,255,255,0.08)", borderRadius:"4px", overflow:"hidden" }}><div style={{ height:"100%", width:`${item.pct}%`, background:item.color, borderRadius:"4px" }} /></div>
                </div>
              ))}
            </div>
            {REPURCHASE_TACTICS.map((rt,i) => (
              <div key={i} style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"14px", padding:"14px", marginBottom:"10px" }}>
                <div style={{ fontWeight:"700", fontSize:"13px", marginBottom:"8px", color:"#A855F7" }}>{rt.tactic}</div>
                <div onClick={() => copyText(rt.script,`rt-${i}`)} style={{ background:"rgba(0,0,0,0.3)", borderRadius:"10px", padding:"10px 12px", fontSize:"13px", lineHeight:"1.7", cursor:"pointer", display:"flex", justifyContent:"space-between", gap:"8px", border:"1px solid rgba(123,47,190,0.2)" }}>
                  <span>"{rt.script}"</span>
                  <span style={{ fontSize:"16px", flexShrink:0 }}>{copiedId===`rt-${i}` ? "✅" : "📋"}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "hashtags" && (
          <div>
            <div style={{ background:"rgba(10,132,255,0.1)", border:"1px solid rgba(10,132,255,0.3)", borderRadius:"12px", padding:"12px 14px", marginBottom:"16px", fontSize:"13px", lineHeight:"1.7" }}>
              📌 <strong>สูตร Hashtag TikTok Shop:</strong> ใช้ <span style={{ color:"#0A84FF" }}>3-4 กลุ่ม</span> ต่อวิดีโอ รวมไม่เกิน <span style={{ color:"#0A84FF" }}>15 แท็ก</span>
            </div>
            {Object.entries(HASHTAG_SETS).map(([group,tags]) => (
              <div key={group} style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"14px", padding:"14px", marginBottom:"10px" }}>
                <div style={{ fontWeight:"700", fontSize:"13px", marginBottom:"10px", color:"rgba(255,255,255,0.7)" }}>กลุ่ม: {group}</div>
                <div style={{ display:"flex", flexWrap:"wrap", gap:"6px" }}>
                  {tags.map((tag,i) => (
                    <div key={i} onClick={() => copyText(tag,`tag-${group}-${i}`)} style={{ background: copiedId===`tag-${group}-${i}` ? "rgba(48,209,88,0.2)" : "rgba(255,255,255,0.08)", border:`1px solid ${copiedId===`tag-${group}-${i}` ? "#30D158" : "rgba(255,255,255,0.15)"}`, borderRadius:"20px", padding:"5px 12px", fontSize:"12px", cursor:"pointer", color: copiedId===`tag-${group}-${i}` ? "#30D158" : "#F0F0F0" }}>
                      {copiedId===`tag-${group}-${i}` ? "✓ " : ""}{tag}
                    </div>
                  ))}
                </div>
              </div>
            ))}
            <div style={{ background:"linear-gradient(135deg,rgba(255,59,92,0.1),rgba(123,47,190,0.1))", border:"1px solid rgba(255,59,92,0.3)", borderRadius:"14px", padding:"14px" }}>
              <div style={{ fontWeight:"700", fontSize:"13px", marginBottom:"8px" }}>🎯 Copy ทั้งชุด (Beauty/Skincare)</div>
              <div style={{ fontSize:"12px", color:"rgba(255,255,255,0.6)", lineHeight:"1.9", marginBottom:"10px" }}>#TikTokShopไทย #สกินแคร์ #ครีมทาหน้า #หน้าขาว #รูขุมขน<br/>#GRWM #สกินแคร์รูทีน #BeforeAfter #ของดีบอกต่อ<br/>#โปรวันนี้ #ราคาพิเศษ #fyp #fypシ #viral</div>
              <button onClick={() => copyText("#TikTokShopไทย #สกินแคร์ #ครีมทาหน้า #หน้าขาว #รูขุมขน #GRWM #สกินแคร์รูทีน #BeforeAfter #ของดีบอกต่อ #โปรวันนี้ #ราคาพิเศษ #fyp #fypシ #viral","full-hash")}
                style={{ background: copiedId==="full-hash" ? "#30D158" : "linear-gradient(90deg,#FF3B5C,#7B2FBE)", color:"#fff", border:"none", borderRadius:"10px", padding:"10px 16px", fontSize:"13px", fontWeight:"700", cursor:"pointer", width:"100%" }}>
                {copiedId==="full-hash" ? "✅ Copied!" : "📋 Copy ทั้งชุด"}
              </button>
            </div>
          </div>
        )}
      </div>
      <div style={{ textAlign:"center", padding:"20px", fontSize:"11px", color:"rgba(255,255,255,0.2)" }}>กดที่ Script ใด ๆ เพื่อ Copy ไปใช้ได้เลย</div>
    </div>
  );
}
