import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'

// ── Anthropic API Key Proxy ──
// The app calls https://api.anthropic.com/v1/messages directly from the browser.
// For production, replace with your own backend proxy to keep the API key secret.
//
// Option A (Dev only): set VITE_ANTHROPIC_API_KEY in .env
//   → The fetch calls in App.jsx will use this key via the proxy below.
//
// Option B (Recommended for prod): deploy a small Express/Next.js proxy
//   → Change all fetch("https://api.anthropic.com/...") calls to fetch("/api/claude")
//
// The current build works as-is on Claude.ai Artifacts (no key needed there).

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
