# 🎬 TikTok Content System

ระบบบริหารคอนเทนต์ TikTok Shop แบบครบวงจร — AI-powered  
**GMV-Max Clip Analyzer · Hook Generator · Script Builder · CTA Engine · AI Weekly Insights**

---

## ✨ Features

| Feature | Description |
|---|---|
| 📦 **สินค้า** | วางลิงก์ TikTok + Screenshot → AI วิเคราะห์สินค้า + Gen คอนเทนต์ครบชุด |
| 🎬 **Clip Analyzer** | อัปโหลด Screen-record สูงสุด 5 คลิป → AI วิเคราะห์ GMV-Max Structure |
| 🧠 **AI Insights** | ป้อน Performance รายวัน → AI เลือก KPI / Hook / CTA / เวลาโพสต์ + Weekly Insight |
| 🎣 **Hook 3 วิ** | 3 สูตร (Pain / Result / Secret) พร้อม Stop Trigger + ตัวอย่าง Copy ได้เลย |
| 🎬 **แนวเนื้อหา** | 4 แนว (GRWM / Before&After / Tutorial / Review) พร้อม Script Structure |
| 🛒 **CTA** | 7 แบบ พร้อม Psychology Trigger + Invisible CTA techniques |
| 🔄 **ซื้อซ้ำ** | 5 Tactic + Content Ratio Chart เพื่อเพิ่ม Repurchase Rate |
| #️⃣ **Hashtag** | 5 กลุ่ม + Copy ทั้งชุดพร้อมใช้ |

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Anthropic API Key → [console.anthropic.com](https://console.anthropic.com/)

### Installation

```bash
# 1. Clone repo
git clone https://github.com/YOUR_USERNAME/tiktok-content-system.git
cd tiktok-content-system

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env
# Edit .env and add your VITE_ANTHROPIC_API_KEY

# 4. Run dev server
npm run dev
# → Opens at http://localhost:3000
```

---

## 🔑 API Key Setup

### Option A — Dev Only (ง่ายที่สุด)
เพิ่ม key ใน `.env`:
```
VITE_ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxx
```
แล้วแก้ทุก `fetch("https://api.anthropic.com/v1/messages", ...)` ใน `src/App.jsx` ให้ใส่ header:
```js
headers: {
  "Content-Type": "application/json",
  "x-api-key": import.meta.env.VITE_ANTHROPIC_API_KEY,
  "anthropic-version": "2023-06-01",
  "anthropic-dangerous-direct-browser-access": "true",
}
```

### Option B — Production (แนะนำ)
Deploy backend proxy (Express / Next.js API Route) แล้วเปลี่ยน URL ทุกจุดจาก:
```
https://api.anthropic.com/v1/messages
```
เป็น:
```
/api/claude
```
วิธีนี้ API key จะไม่ถูก expose ใน browser

---

## 📁 Project Structure

```
tiktok-content-system/
├── src/
│   ├── App.jsx          # Main app — all components in one file
│   └── main.jsx         # React entry point
├── index.html           # HTML template
├── vite.config.js       # Vite configuration
├── package.json
├── .env.example         # Environment variable template
├── .gitignore
└── README.md
```

---

## 🎬 Clip Analyzer — วิธีใช้งาน

1. เพิ่มสินค้าในแท็บ **📦 สินค้า** (วางลิงก์ TikTok + Screenshot)
2. กด **✨ Gen** เพื่อ generate คอนเทนต์
3. เลื่อนลงมาถึงส่วน **🎬 วิเคราะห์คลิปตัวอย่าง**
4. กด **+ เพิ่มคลิป** → เลือก screen-record .mp4 จาก TikTok (สูงสุด 5 คลิป)
5. วางลิงก์ TikTok ของแต่ละคลิป (ไม่บังคับ)
6. กด **🎬 วิเคราะห์ X คลิป → GMV-Max Structure**

**Output ที่ได้:**
- Hook / Script Structure / CTA analysis ต่อคลิป
- GMV Score (Hook + Demo + CTA + Trust)
- GMV-Max Blueprint สังเคราะห์จากทุกคลิป
- Best Script Template + Top Hashtags + Next Step Recommendation

---

## 🧠 AI Intelligence — วิธีใช้งาน

1. ไปที่แท็บ **🧠 AI Insights**
2. กด **เริ่มวิเคราะห์ด้วย AI**
3. กรอกข้อมูลสินค้า + Performance รายวัน (Views / Clicks / Orders / เวลา / Hook / CTA)
4. กรอกอย่างน้อย 3 วัน → กด **วิเคราะห์ด้วย AI**

**Output ที่ได้ (7 หัวข้อ):**
- 🛍️ Product Type Analysis + Buyer Persona
- 📊 KPI Selection + Ranking พร้อมเหตุผล
- 🎣 Best Hook Score + Script
- 🛒 CTA Conversion Ranking
- ⏰ Best Posting Time Slots
- 🧠 Weekly Win/Problem/Action Items
- 🗓️ Content Calendar สัปดาห์หน้า

---

## 🛡️ TikTok Compliance

ระบบมี built-in compliance check ทุกครั้งที่ AI generate คอนเทนต์:
- ✅ ไม่อ้างว่าสินค้ารักษาโรค
- ✅ ไม่ใช้ตัวเลขเกินจริง
- ✅ ไม่เปรียบเทียบแบรนด์คู่แข่งโดยชื่อ
- ✅ สคริปต์ต้องฟังดูเป็น personal experience จริง

---

## 🚢 Deploy

### Vercel (แนะนำ)
```bash
npm run build
# Push to GitHub → Connect repo to vercel.com → Deploy
```

### Netlify
```bash
npm run build
# Drag dist/ folder to netlify.com/drop
```

---

## 📄 License

MIT — ใช้งานได้อิสระ ทั้ง personal และ commercial

---

## 🤝 Contributing

Pull requests ยินดีรับ — โดยเฉพาะ:
- เพิ่มหมวดหมู่สินค้าใหม่
- เพิ่ม Hook / CTA templates
- Backend proxy สำหรับ production

---

*Built with React + Vite + Anthropic Claude API*
